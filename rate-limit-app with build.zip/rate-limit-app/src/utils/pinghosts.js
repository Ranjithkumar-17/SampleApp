import ping from 'ping';

// 👇️ use this import if you use CommonJS require()
// const ping = require('ping');

const hosts = ['192.168.1.1', 'google.com', 'yahoo.com'];

async function pingHosts() {
    for (const host of hosts) {
        const response = await ping.promise.probe(host);
        console.log(response);
        ping.sys.probe(host, function (isAlive) {
            const message = isAlive
                ? 'host ' + host + ' is online'
                : 'host ' + host + ' is OFFLINE';

            console.log(message);
        });
    }
}

pingHosts();

// PS C:\reactjs\rate-limit-app> node --watch ./src/utils/pinghosts.js
// module.exports = {
//     pinghosts,
// }
