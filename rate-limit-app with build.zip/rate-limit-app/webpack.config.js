import path from 'path';

export default {
  mode: 'development', // Change 'dev' to 'development'
  entry: './src/index.js', // Use ':' for the assignment instead of '='
  output: {
    path: path.join(process.cwd(), '\\dist'), // Use 'path.join' instead of 'join'
    publicPath: '/apidocs',
    filename: 'centrallibrary.js',
  },
  target: 'node',
};