package in.sis.api.dao;

import java.util.List;
import java.util.Map;

public interface FetchReqResForSchemaRepository {

	public List<Map<String,Object>> fetchReqRes();
	
}
