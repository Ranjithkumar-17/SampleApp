package in.sis.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FetchApiForPathRepositoryImpl implements FetchApiForPathRepository {

	@Autowired
	JdbcTemplate jdbcTemp;
	
	
//	private String libraryquery = "SELECT          -- Insert query\r\n"
//			+ "    replace(method_name, ' ', '')      method_name,\r\n"
//			+ "    input_parameters,\r\n"
//			+ "    output_parameters,\r\n"
//			+ "    replace(application_name, ' ', '') application_name,\r\n"
//			+ "    service_url,\r\n"
//			+ "    ('\"'||api_description||'\"') as api_description\r\n"
//			+ "FROM\r\n"
//			+ "    ps_tb_central_library\r\n"
//			+ "WHERE\r\n"
//			+ "        environment <> 'Hold'\r\n"
//			+ "    AND application_name NOT IN ( 'sfpbfdms', 'sfpbfum', 'sfpbfcam', 'sfpbfcrif', 'icrservices',\r\n"
//			+ "                                  'OnlineSundaramService', 'psexternalenquiry', 'oplogin', 'optrans', 'opcommon',\r\n"
//			+ "                                  'openquiry', 'sfapiexposurenote', 'sfapiexistingexposurenote' )\r\n"
//			+ "    AND method_name = 'generateOtp'";
	
	private String libraryquery = "SELECT   -- Path Query\r\n"
			+ "    replace(method_name, ' ', '')      method_name,\r\n"
			+ "    input_parameters,\r\n"
			+ "    output_parameters,\r\n"
			+ "    replace(application_name, ' ', '') application_name,\r\n"
			+ "    service_url,\r\n"
			+ "    ( '\\\"'\r\n"
			+ "      || api_description\r\n"
			+ "      || '\\\"' )                          AS api_description\r\n"
			+ "FROM\r\n"
			+ "    ps_tb_central_library\r\n"
			+ "WHERE\r\n"
			+ "        environment <> 'Hold'\r\n"
			+ "    AND application_name NOT IN ( 'sfpbfdms', 'sfpbfum', 'sfpbfcam', 'sfpbfcrif', 'icrservices',\r\n"
			+ "                                  'OnlineSundaramService', 'psexternalenquiry', 'oplogin', 'optrans', 'opcommon',\r\n"
			+ "                                  'openquiry', 'sfapiexposurenote', 'sfapiexistingexposurenote' )\r\n"
			+ "    AND METHOD_NAME != 'getappupdate'\r\n"
			+ "ORDER BY\r\n"
			+ "    sl_no";
//	private String libraryquery = "SELECT * FROM ps_tb_central_library where METHOD_NAME='leadgen'" ;
	
	@Override
	public List<Map<String, Object>> fetchApi() {
		
		List<Map<String, Object>> apiList = null;
		
		try{
			apiList = jdbcTemp.queryForList(libraryquery);
//			System.out.println(apiList);
		}
		catch (Exception e) {
			
			System.out.println("Exception "+e.toString());
			return null;
		}
		return apiList;
	}

}
