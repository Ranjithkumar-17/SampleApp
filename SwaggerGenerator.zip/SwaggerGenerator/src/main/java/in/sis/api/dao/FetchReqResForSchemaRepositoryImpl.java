package in.sis.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FetchReqResForSchemaRepositoryImpl implements FetchReqResForSchemaRepository {

	@Autowired
	JdbcTemplate jdbcTemp;
	
//	String sql = "SELECT   ---  Schema Query\r\n"
//			+ "    replace(method_name, ' ', '') method_name,\r\n"
//			+ "    input_parameters,\r\n"
//			+ "    output_parameters\r\n"
//			+ "FROM\r\n"
//			+ "    ps_tb_central_library\r\n"
//			+ "WHERE\r\n"
//			+ "        environment <> 'Hold'\r\n"
//			+ "    AND application_name NOT IN ( 'sfpbfdms', 'sfpbfum', 'sfpbfcam', 'sfpbfcrif', 'icrservices',\r\n"
//			+ "                                  'OnlineSundaramService', 'psexternalenquiry', 'oplogin', 'optrans', 'opcommon',\r\n"
//			+ "                                  'openquiry', 'sfapiexposurenote', 'sfapiexistingexposurenote' )\r\n"
//			+ "     AND sl_no <= 500";
	String sql = "SELECT\r\n"
			+ "    REPLACE(METHOD_NAME, ' ', '') METHOD_NAME,\r\n"
			+ "    INPUT_PARAMETERS,\r\n"
			+ "    OUTPUT_PARAMETERS\r\n"
			+ "FROM\r\n"
			+ "    ps_tb_central_library\r\n"
			+ "WHERE\r\n"
			+ "        environment <> 'Hold'\r\n"
			+ "    AND application_name NOT IN ( 'sfpbfdms', 'sfpbfum', 'sfpbfcam', 'sfpbfcrif', 'icrservices',\r\n"
			+ "                                  'OnlineSundaramService', 'psexternalenquiry', 'oplogin', 'optrans', 'opcommon',\r\n"
			+ "                                  'openquiry', 'sfapiexposurenote', 'sfapiexistingexposurenote' )\r\n"
			+ "ORDER BY\r\n"
			+ "    sl_no";
//			+ "FETCH FIRST 100 ROWS ONLY";
	
	@Override
	public List<Map<String, Object>> fetchReqRes() {
		
		List<Map<String, Object>> reqResList = null;

		try {
			reqResList = jdbcTemp.queryForList(sql);
//			System.out.println(reqResList);
			
		}
		catch (Exception e) {
			
			System.out.println("Exception "+e.toString());
			return null;
		}
		return reqResList;
	}

}
