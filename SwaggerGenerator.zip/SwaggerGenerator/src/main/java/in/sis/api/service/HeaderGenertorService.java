package in.sis.api.service;

import java.util.Map;

public interface HeaderGenertorService {
	
	public Map<String, Object> generateHead();
}
