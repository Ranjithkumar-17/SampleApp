package in.sis.api.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator;

import in.sis.api.dao.FetchInfoForHeaderRepository;

@Service
public class HeaderGeneratorServiceImpl implements HeaderGenertorService {

	@Autowired
	FetchInfoForHeaderRepository repo;

	@Override
	public Map<String, Object> generateHead() {

		Map<String, Object> response = new HashMap<>();

		List<Map<String, Object>> list = repo.fetchDetails();

		if (list != null) {

			Map<String, Object> yaml = new LinkedHashMap();
			Map<String, Object> info = new LinkedHashMap<String, Object>();
			Map<String, String> contact = new HashMap();
			Map<String, String> externalDocs = new HashMap();
			List<Object> servers1 = new ArrayList<>();
			Map<String, Object> servers = new LinkedHashMap<String, Object>();
			Map<String, Object> variables = new LinkedHashMap<String, Object>();
			Map<String, Object> scheme = new HashMap();
			List<String> schemeEnum = new ArrayList<>();
			List<String> portEnum = new ArrayList<>();
			Map<String, Object> port = new HashMap();
			Map<String, Object> appcontext = new HashMap();
			List<Map<String, Object>> tagsList = new ArrayList<Map<String,Object>>();
			
			Map<String, Object> tagsExternalDocs = new HashMap<>();
			List<String> appcontextEnum = new ArrayList<>();

			yaml.put("openapi", "3.0.0");

			info.put("title", "API Central Library");
			info.put("version", "1.0.1");
			info.put("termsOfService", "http://swagger.io/terms/");

			contact.put("name", ": 🚨Delivery Excellance");
			contact.put("email", "rkrish@sundaraminfotech.in");

			info.put("contact", contact);

			externalDocs.put("description", "Find out more about Swagger");
			externalDocs.put("url", "http://swagger.io");

			schemeEnum.add("http");
			schemeEnum.add("https");

			scheme.put("default", "http");
			scheme.put("enum", schemeEnum);

			portEnum.add("80");
			portEnum.add("443");
			portEnum.add("8000");
			portEnum.add("8010");
			portEnum.add("8070");
			portEnum.add("8082");
			portEnum.add("8086");
			portEnum.add("9090");
			portEnum.add("8280");

			port.put("enum", portEnum);
			port.put("default", "9090");
			port.put("description", "Select your server port here");

			appcontextEnum.add("application_context");
			for (Map<String, Object> context : list) {
				appcontextEnum.add((String) context.get("APPLICATION_NAME"));
			}
			
			appcontext.put("enum", appcontextEnum);
			appcontext.put("default", "application_context");
			appcontext.put("description", "Enter your app context name here");

			variables.put("scheme", scheme);
			variables.put("port", port);
			variables.put("appcontext", appcontext);

			servers.put("url", "{scheme}://apiservicedev:{port}/{appcontext}");
			servers.put("description", "Common Development API Services");
			servers.put("variables", variables);
			
			servers1.add(servers);

			tagsExternalDocs.put("description", "Find out more");
			tagsExternalDocs.put("url", "http://swagger.io");

			for(String tag : appcontextEnum) {
				if(tag.equals("application_context")) {
					continue;
				}
				Map<String, Object> tags = new HashMap<>();
				tags.put("name", tag);
				tags.put("description", "Used in SME");
				tags.put("externalDocs", tagsExternalDocs);
				tagsList.add(tags);	
			}
			yaml.put("info", info);
			yaml.put("externalDocs", externalDocs);
			yaml.put("servers", servers1);
			yaml.put("tags", tagsList);
			
			ObjectMapper objectMapper = new ObjectMapper(
					new YAMLFactory().disable(YAMLGenerator.Feature.WRITE_DOC_START_MARKER));

			StringBuilder result = new StringBuilder();

			try {
				result.append(objectMapper.writeValueAsString(yaml));
				JsonNode jsonNodeschema = objectMapper.readTree(result.toString());
				response.put("Response", jsonNodeschema);
			} catch (JsonProcessingException e) {

				e.printStackTrace();
			}

		}

		return response;
	}

}
