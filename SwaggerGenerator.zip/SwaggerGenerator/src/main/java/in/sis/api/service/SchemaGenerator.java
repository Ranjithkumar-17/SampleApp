package in.sis.api.service;

import java.io.IOException;
import java.util.Map;

public interface SchemaGenerator {

	public Map<String, Object> generateSchema() throws IOException;
}
