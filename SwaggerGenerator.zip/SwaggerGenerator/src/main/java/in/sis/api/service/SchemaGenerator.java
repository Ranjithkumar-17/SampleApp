package in.sis.api.service;

import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public interface SchemaGenerator {

	public Map<String,String> generateSchema() throws IOException;
}
