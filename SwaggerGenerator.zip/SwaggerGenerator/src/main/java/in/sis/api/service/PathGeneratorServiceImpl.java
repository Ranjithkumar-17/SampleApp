package in.sis.api.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator;

import in.sis.api.dao.FetchApiForPathRepository;

@Service
public class PathGeneratorServiceImpl implements PathGeneratorService {

	@Autowired
	FetchApiForPathRepository repo;

	String methodName;

	boolean flag = false;
	JsonNode result = null;

	@Override
	public Map<String, Object> generatePaths() {

		Map<String, Object> response = new HashMap<>();
		Map<String, Object> path = new HashMap<>();

		
		result = swaggerformat();
		
		if(result != null) {
			path.put("paths", result);
			response.put("code", "0");
			response.put("type", "Success");
			response.put("Response", path);
			
			return response;
		}
		else {
			response.put("code", "1");
			response.put("Message", methodName);
			response.put("type", "Failure");
			return response;
		}
	}

	private static Map<String, Object> createSecurityObject(String name, List<String> scopes) {
		Map<String, Object> securityObject = new HashMap<>();
		securityObject.put(name, scopes);
		return securityObject;
	}

	public JsonNode swaggerformat() {
		String response = null;
		List<Map<String, Object>> apiLsit = repo.fetchApi();
		ObjectMapper objectMapper = new ObjectMapper(
				new YAMLFactory().disable(YAMLGenerator.Feature.WRITE_DOC_START_MARKER));
		StringBuilder result = new StringBuilder();
		
		
		try{
			
			List<Map<String, Object>> librarymap = repo.fetchApi();
			
			if( librarymap == null){
				
				methodName = "query failure";
				return null;
			}
			
			for (Map<String, Object> librarydtls : librarymap) {
				
				methodName = (String) librarydtls.get("METHOD_NAME");
				
//				System.out.println(methodName);
				
				if(librarydtls.get("INPUT_PARAMETERS") == null && librarydtls.get("OUTPUT_PARAMETERS") == null) {
					continue;
				}

				Map<String, Object> swaggerSpec = new HashMap<>();
				List<String> tags = new ArrayList<>();
				Map<String, Object> postOperation = new LinkedHashMap<>();
				Map<String, Object> requestBody = new HashMap<>();
				Map<String, Object> content = new HashMap<>();
				Map<String,Object> requestSchema = new HashMap<>();
				Map<String,Object> responseSchema = new HashMap<>();
				Map<String,Object> responseschema = new HashMap<>();
				Map<String, Object> responses = new HashMap<>();
				Map<String, Object> response200 = new HashMap<>();
				Map<String, Object> response400 = new HashMap<>();
				Map<String, Object> response404 = new HashMap<>();
				Map<String, Object> response405 = new HashMap<>();

				List<Map<String, Object>> security = new ArrayList<>();
				Map<String, Object> apiInfo = new HashMap<>();
				Map<String, Object> postOperation1 = new LinkedHashMap<>();
				Map<String, Object> schema1 = new HashMap<>();
				Map<String, Object> schema2 = new HashMap<>();
				Map<String, List<Object>> multischeme = new HashMap<>();
				String applicationname =librarydtls.get("APPLICATION_NAME") !=null? librarydtls.get("APPLICATION_NAME").toString():null;

				String methodname = librarydtls.get("METHOD_NAME").toString();
				String url = librarydtls.get("SERVICE_URL").toString();

				String part1 = null;
				if(applicationname != null) {
					String afterspl[] = url.split("/" + applicationname, url.length());
					 part1 = afterspl[1];
//					System.out.println("URL "+part1);
				}
				

				// Fill in the Swagger specification data
				tags.add(librarydtls.get("APPLICATION_NAME").toString());
				response200.put("description", "Successful operation");
				
				if(librarydtls.get("OUTPUT_PARAMETERS") != null) {
					
					Map<String, Object> content200 = new HashMap<>();
					schema2.put("$ref", "#/components/schemas/" +(librarydtls.get("METHOD_NAME") != null? librarydtls.get("METHOD_NAME").toString():null)+ "Response");
					responseSchema.put("schema", schema2);
					content200.put("application/json", responseSchema);
					response200.put("content", content200);
					
				}
				response400.put("description", "Invalid ID supplied");
				response404.put("description", "Pet not found");
				response405.put("description", "Validation exception");
				responses.put("200", response200);
				responses.put("400", response400);
				responses.put("404", response404);
				responses.put("405", response405);
				schema1.put("$ref", "#/components/schemas/" + librarydtls.get("METHOD_NAME").toString() + "Request");
				
				requestSchema.put("schema", schema1);
				content.put("application/json", requestSchema);
				requestBody.put("description", librarydtls.get("API_DESCRIPTION") != null? librarydtls.get("API_DESCRIPTION").toString():"null");
				requestBody.put("content", content);
				requestBody.put("required", true);

				postOperation1.put("tags", tags);
				postOperation.put("post", postOperation1);
				// postOperation.put("summary", "To validate OTP provided by the customer");
				postOperation1.put("description", librarydtls.get("API_DESCRIPTION") != null? librarydtls.get("API_DESCRIPTION").toString():"null");
//				postOperation1.put("operationId", librarydtls.get("METHOD_NAME") !=null?librarydtls.get("METHOD_NAME").toString():null);
				postOperation1.put("operationId", part1.replace("\"", ""));
				
				if(librarydtls.get("INPUT_PARAMETERS") != null) {
					postOperation1.put("requestBody", requestBody);
				}
				postOperation1.put("responses", responses);
				
				// apiInfo.put("/api/v1/validateOtp", postOperation1);
				security.add(createSecurityObject("BearerAuth", new ArrayList<>()));
				postOperation1.put("security", security);
				swaggerSpec.put(part1, postOperation);

				// postOperation.add(securityinfo);
				// swaggerSpec.put("openapi", "3.0.0");
				// swaggerSpec.put("paths", apiInfo);

				// Convert the Java object to YAML using Jackson YAML
				result.append(objectMapper.writeValueAsString(swaggerSpec));
				
//				System.out.println(multischeme);
			}
			StringBuilder contents = null;
			contents = new StringBuilder();
			contents.append(result);

			Map<String, Object> pathmap = new HashMap<>();

			pathmap.put("paths", result);
			response = contents.toString();
			JsonNode jsonNode = objectMapper.readTree(contents.toString());
			return jsonNode;
		}
		catch( Exception e){
			methodName = " Error while parsing "+methodName;
			return null;
		}
	}
}
