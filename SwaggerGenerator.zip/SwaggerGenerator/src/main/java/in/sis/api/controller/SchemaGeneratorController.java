package in.sis.api.controller;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.sis.api.service.SchemaGenerator;

@RestController
@RequestMapping("api")
public class SchemaGeneratorController {

	@Autowired
	SchemaGenerator generator;
	

	@PostMapping(value = "v1/schemaGenerator")
	public Map<String, Object> generateSchema() throws IOException {
		return generator.generateSchema();
	}

}