package in.sis.api.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@PropertySource(value= {"file:${PROJECT_HOME}/ext_application.properties"})
public class DataSource {
	
	@Value("${spring.datasource.driver-class-name}")
	private String driverName;

	@Value("${spring.datasource.url}")
	private String url;

	@Value("${spring.datasource.username}")
	private String userName;

	@Value("${spring.datasource.password}")
	private String password;

	@Bean
	public DriverManagerDataSource getDataSource() throws Exception {

		DriverManagerDataSource dataSource =  new DriverManagerDataSource();
        dataSource.setDriverClassName(driverName);
        dataSource.setUrl(url);
        dataSource.setUsername(userName);
        dataSource.setPassword(password);
        System.out.println("DatabaseConfig [driverClassName=" + driverName + ", url=" + url + ", userName=" + userName + ", password=" + password + "]");
        return dataSource;

	}
}
