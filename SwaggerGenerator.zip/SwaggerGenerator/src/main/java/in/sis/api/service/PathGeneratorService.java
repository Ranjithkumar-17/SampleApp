package in.sis.api.service;

import java.util.Map;

public interface PathGeneratorService {
	
	public Map<String, Object> generatePaths();
}
