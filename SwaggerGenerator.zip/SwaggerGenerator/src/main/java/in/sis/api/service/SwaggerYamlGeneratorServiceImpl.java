package in.sis.api.service;

import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

@Service
public class SwaggerYamlGeneratorServiceImpl implements SwaggerYamlGeneratorService {

	String pathGenerator = "http://localhost:8081/generator/api/v1/pathGenerator";
	String componentGenerator = "http://localhost:8081/generator/api/v1/schemaGenerator";
	String filePath = "D:\\centrallibrary\\fileToCreate.txt";

	@Override
	public Map<String, String> geneateSwagger() throws JsonMappingException, JsonProcessingException {
		
		RestTemplate restTemp = new RestTemplate();
		ObjectMapper objMapper = new ObjectMapper();


		Map<String, String> response = new HashMap<>();

		String pathApiresponse = restTemp.exchange(pathGenerator, HttpMethod.POST, null, String.class).getBody();
		JsonNode pathResponse = objMapper.readTree(pathApiresponse);
		
		System.out.println("Path Response : "+pathResponse.get("Response")); 
		
		if (pathResponse.get("code").asInt()==0) {

			String schemaApiresponse = restTemp.exchange(componentGenerator, HttpMethod.POST, null, String.class)
					.getBody();

			JsonNode schemaResponse = objMapper.readTree(schemaApiresponse);

			if (schemaResponse.get("code").asInt()==0) {

				ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());
				String yamlSchemaProp = yamlMapper.writeValueAsString(pathResponse.get("Response"));
				
				try (FileWriter writer = new FileWriter(filePath)) {
					
					writer.write(yamlSchemaProp);
					
				} catch (Exception e) {
					System.out.println("Unable to write to the file." + e);
				}
				
				response.put("code", "0");
				response.put("message", "yaml created");
			} else {
				response.put("code", "1");
				response.put("message", "schema API error");
			}
		}
		else {
			response.put("code", "1");
			response.put("message", "path API error");
		}
		return response;
	}

}
