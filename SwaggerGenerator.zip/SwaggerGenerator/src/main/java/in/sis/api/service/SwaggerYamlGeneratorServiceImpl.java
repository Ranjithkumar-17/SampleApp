package in.sis.api.service;

import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

@Service
public class SwaggerYamlGeneratorServiceImpl implements SwaggerYamlGeneratorService {

	String pathGenerator = "http://localhost:8081/generator/api/v1/pathGenerator";
	String componentGenerator = "http://localhost:8081/generator/api/v1/schemaGenerator";
	String headerGenerator = "http://localhost:8081/generator/api/v1/headerGenerator";
	String filePath = "D:\\centrallibrary\\fileToCreate.txt";

	@Override
	public Map<String, String> geneateSwagger() throws JsonMappingException, JsonProcessingException {

		RestTemplate restTemp = new RestTemplate();
		ObjectMapper objMapper = new ObjectMapper();

		Map<String, String> response = new HashMap<>();

		String HeaderResponse = restTemp.exchange(headerGenerator, HttpMethod.POST, null, String.class).getBody();
		JsonNode headResponse = objMapper.readTree(HeaderResponse);
		
		String pathApiresponse = restTemp.exchange(pathGenerator, HttpMethod.POST, null, String.class).getBody();
		JsonNode pathResponse = objMapper.readTree(pathApiresponse);

		if (pathResponse.get("code").asInt() == 0) {

			String schemaApiresponse = restTemp.exchange(componentGenerator, HttpMethod.POST, null, String.class)
					.getBody();

			JsonNode schemaResponse = objMapper.readTree(schemaApiresponse);

			if (schemaResponse.get("code").asInt() == 0) {

				Map<String,Object> swaggerYaml = new HashMap<String, Object>();
				
				
				
				
				ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());
				String path = yamlMapper.writeValueAsString(pathResponse.get("Response"));
				path = path.replace("---\n", "");
				String schema = yamlMapper.writeValueAsString(schemaResponse.get("Schemas"));
				schema = schema.replace("---\n", "");
				String head = yamlMapper.writeValueAsString(headResponse.get("Response"));
				head = head.replace("---\n", "");

				File file = new File(filePath);
				if (file.exists()) {
					file.delete();
					file = new File(filePath);
				} else {
					file = new File(filePath);
				}

				try (FileWriter writer = new FileWriter(filePath)) {

					writer.write(head + path + schema);
					response.put("code", "0");
					response.put("type", "Success");
					response.put("message", "yaml created");
					System.out.println("File Created");

				} catch (Exception e) {
					response.put("code", "1");
					response.put("type", "Failure");
					response.put("message", e.getMessage());
				}

			} else {
				response.put("code", "1");
				response.put("type", "Failure");
				response.put("message", "schema API error");
			}
		} else {
			response.put("code", "1");
			response.put("type", "Failure");
			response.put("message", "path API error");
		}

		return response;
	}
}
