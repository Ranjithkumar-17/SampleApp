package in.sis.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class FetchInfoForHeaderRepositoryImpl implements FetchInfoForHeaderRepository {

	@Autowired
	JdbcTemplate jdbcTemp;
	
	String sql = "SELECT DISTINCT\r\n"
			+ "    substr(substr(a.service_url, instr(a.service_url, ':', - 1) + 1, instr(a.service_url, '/', - 1) - instr(a.service_url, ':', - 1) -\r\n"
			+ "    1), 1, instr(substr(a.service_url, instr(a.service_url, ':', - 1) + 1, instr(a.service_url, '/', - 1) - instr(a.service_url, ':', -\r\n"
			+ "    1) - 1), '/') - 1) port_number,\r\n"
			+ "    application_name\r\n"
			+ "FROM\r\n"
			+ "    ps_tb_central_library a\r\n"
			+ "WHERE\r\n"
			+ "    application_name NOT IN ( 'sfpbfdms', 'sfpbfum', 'sfpbfcam', 'sfpbfcrif', 'icrservices',\r\n"
			+ "                              'OnlineSundaramService', 'psexternalenquiry', 'oplogin', 'optrans', 'opcommon',\r\n"
			+ "                              'openquiry', 'sfapiexposurenote', 'sfapiexistingexposurenote' )";
	
	@Override
	public List<Map<String, Object>> fetchDetails() {
		
		List<Map<String, Object>> details = null;
		
		try{
			details = jdbcTemp.queryForList(sql);
//			System.out.println(reqResList);
			
		}
		catch (Exception e) {
			
			System.out.println("Exception "+e.toString());
			return null;
		}
		
		return details;
	}

}
