package in.sis.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class FetchInfoForHeaderRepositoryImpl implements FetchInfoForHeaderRepository {

	@Autowired
	JdbcTemplate jdbcTemp;
	
	String sql = "select APPLICATION_NAME from ps_tb_central_library";
	
	
	@Override
	public List<Map<String, Object>> fetchDetails() {
		
		List<Map<String, Object>> details = null;
		
		try{
			details = jdbcTemp.queryForList(sql);
//			System.out.println(reqResList);
			
		}
		catch (Exception e) {
			
			System.out.println("Exception "+e.toString());
			return null;
		}
		
		return details;
	}

}
