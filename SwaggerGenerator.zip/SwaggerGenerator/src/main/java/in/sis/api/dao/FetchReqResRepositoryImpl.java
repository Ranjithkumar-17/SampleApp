package in.sis.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FetchReqResRepositoryImpl implements FetchReqResRepository {

	@Autowired
	JdbcTemplate jdbcTemp;
	
	String sql = "SELECT INPUT_PARAMETERS,OUTPUT_PARAMETERS,METHOD_NAME FROM ps_tb_central_library";
	
	@Override
	public List<Map<String, Object>> fetchReqRes() {
		
		List<Map<String, Object>> reqResList = null;
		
		try{
			reqResList = jdbcTemp.queryForList(sql);
			System.out.println(reqResList);
			
		}
		catch (Exception e) {
			
			System.out.println("Exception "+e.toString());
			return null;
		}
		return reqResList;
	}

}
