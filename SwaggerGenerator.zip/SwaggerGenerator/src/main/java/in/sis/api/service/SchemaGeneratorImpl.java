package in.sis.api.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import in.sis.api.dao.FetchReqResRepository;

@Service
public class SchemaGeneratorImpl implements SchemaGenerator {

	@Autowired
	FetchReqResRepository repo;

	static String yamlSchemaProp = "";
	static StringBuffer schema = new StringBuffer("{\"components\":{\"SCHEMAS\":{");
	static StringBuffer schemaSubProp = new StringBuffer("{");
	static boolean flag = false;
	static Map<String, Boolean> flag2 = new HashMap<String, Boolean>();
	static ObjectMapper objMapper = new ObjectMapper();
	
	@Override
	public Map<String, String> generateSchema() throws IOException {

		
		Map<String, String> response = new HashMap<>();
		
		List<Map<String, Object>> reqResList = repo.fetchReqRes();

		if(reqResList !=null ) {
			
			try{
				for (Map<String, Object> reqRes : reqResList) {
					
					String inputJsonstr = (String) reqRes.get("INPUT_PARAMETERS");
					JsonNode inputJson = objMapper.readTree(inputJsonstr);
					
					String outputJsonstr = (String) reqRes.get("OUTPUT_PARAMETERS");
					JsonNode outputJson = objMapper.readTree(outputJsonstr);
					
					String schemaPropName = (String) reqRes.get("METHOD_NAME");
					
					StringBuffer reqStr = new StringBuffer("\""+schemaPropName+"Request\":{\"type\":\"object\",\"properties\":{");
					SchemaGeneratorImpl.mainIterator(inputJson,reqStr);
					reqStr.replace(reqStr.length() - 1, reqStr.length(), "}}");
					schema.append(reqStr + ",");
					
					StringBuffer resStr = new StringBuffer("\""+schemaPropName+"Response\":{\"type\":\"object\",\"properties\":{");
					SchemaGeneratorImpl.mainIterator(outputJson,resStr);
					resStr.replace(resStr.length() - 1, resStr.length(), "}}");
					schema.append(resStr + ",");
				}
				schema.replace(schema.length() - 1, schema.length(), "}}}");
				
				
//				ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());
//				JsonNode jsonschemaProp = objMapper.readTree(schema.toString());
//				yamlSchemaProp = yamlMapper.writeValueAsString(jsonschemaProp);
				
				System.out.println(schema);
			}
			catch(Exception e) {
				response.put("Status", "failure");
				response.put("code", "1");
				response.put("message", e.getMessage());
			}
			
			response.put("code", "0");
			response.put("Schemas", yamlSchemaProp);
			return response;
		}
		else {
			response.put("Status", "failure");
			response.put("code", "1");
			response.put("message", "null from query");
		}
		return response;
	}

	// Recursion method to sub json
	public static void generateSubJson(JsonNode jsonObject, String jsonKey) {

		StringBuffer ReqResStr = new StringBuffer("\"" + jsonKey + "Dtls\":{\"type\":\"object\",\"properties\":{");
		jsonObject.fields().forEachRemaining(key -> {

			String keyName = key.getKey();
			String keyType = key.getValue().getNodeType().toString();
			JsonNode keyValue = key.getValue();
			flag2.put(keyName, false);

			if (keyType.equalsIgnoreCase("OBJECT")) {

				flag2.replace(keyName, true);

				SchemaGeneratorImpl.generateSubJson(keyValue, keyName);
			}
			String str = "\"" + keyName + "\":{\"type\":\"" + (Boolean.valueOf(flag2.get(keyName)) ? "array" : "string")
					+ "\"," + (Boolean.valueOf(flag2.get(keyName)) ? "\"items\": {\"$ref\":" : "\"enum\":")
					+ (Boolean.valueOf(flag2.get(keyName)) ? "\"#/components/schemas/" + keyName + "Dtls\"}"
							: "[" + keyValue + "]")
					+ "}";

			ReqResStr.append(str + ",");

		});
		ReqResStr.replace(ReqResStr.length() - 1, ReqResStr.length(), "}}");
		schema.append(ReqResStr + ",");
	}

	// Recursion method to main json
	public static StringBuffer mainIterator(JsonNode json,StringBuffer reqResStr){

		json.fields().forEachRemaining(key -> {
			flag = false;
			String keyName = key.getKey();
			String keyType = key.getValue().getNodeType().toString();
			JsonNode keyValue = key.getValue();
			if (keyType.equalsIgnoreCase("OBJECT")) {
				flag = true;
				SchemaGeneratorImpl.generateSubJson(keyValue, keyName);
			}
			String str = "\"" + keyName + "\":{\"type\":\"" + (flag ? "array" : "string") + "\","
					+ (flag ? "\"items\": {\"$ref\":" : "\"enum\":")
					+ (flag ? "\"#/components/schemas/" + keyName + "Dtls\"}" : "[" + keyValue + "]") + "}";

			reqResStr.append(str + ",");
		});
		return reqResStr;
	}
	
}
