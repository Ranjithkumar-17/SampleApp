package in.sis.api.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator;

import in.sis.api.dao.FetchReqResForSchemaRepository;

@Service
public class SchemaGeneratorImpl implements SchemaGenerator {

	@Autowired
	FetchReqResForSchemaRepository repo;

	static StringBuffer schema = new StringBuffer("{\"components\":{\"schemas\":{");
	static StringBuffer securitySchemes = new StringBuffer("\"securitySchemes\":{");
	static boolean flag = false;
	static Map<String, Boolean> flag2 = new HashMap<String, Boolean>();
	
	ObjectMapper objectMapper = new ObjectMapper(
			new YAMLFactory().disable(YAMLGenerator.Feature.WRITE_DOC_START_MARKER));
	
	
	
	String schemaPropName;
	
	@Override
	public Map<String, Object> generateSchema() throws IOException {
		
		JsonNode jsonNodeschema = null;
		ObjectMapper objMapper = new ObjectMapper();
		
		Map<String, Object> response = new HashMap<>();
		
		List<Map<String, Object>> reqResList = repo.fetchReqRes();

		if(reqResList !=null ) {
			
			System.out.println("inside loop"+reqResList);
			
			try{
				for (Map<String, Object> reqRes : reqResList) {
					
					schemaPropName = (String) reqRes.get("METHOD_NAME");
					System.out.println(schemaPropName);
					
					String inputJsonstr = (String) reqRes.get("INPUT_PARAMETERS");
//					System.out.println("inputJsonstr "+inputJsonstr);

					String outputJsonstr = (String) reqRes.get("OUTPUT_PARAMETERS");
//					System.out.println("outputJsonstr "+outputJsonstr);
					
					if(inputJsonstr != null){
						JsonNode inputJson = objMapper.readTree(inputJsonstr);
						StringBuffer reqStr = new StringBuffer("\""+schemaPropName+"Request\":{\"type\":\"object\",\"properties\":{");
						SchemaGeneratorImpl.mainIterator(inputJson,reqStr);
						reqStr.replace(reqStr.length() - 1, reqStr.length(), "}}");
						schema.append(reqStr + ",");
					}
					if(outputJsonstr != null) {
						JsonNode outputJson = objMapper.readTree(outputJsonstr);
						StringBuffer resStr = new StringBuffer("\""+schemaPropName+"Response\":{\"type\":\"object\",\"properties\":{");
						SchemaGeneratorImpl.mainIterator(outputJson,resStr);
						resStr.replace(resStr.length() - 1, resStr.length(), "}}");
						schema.append(resStr + ",");
					}
				}
				schema.replace(schema.length() - 1, schema.length(), "}}}");
				
				JsonNode securityScheme = generateSecuritySchema();
				
				jsonNodeschema = objectMapper.readTree(schema.toString());
				
				((ObjectNode) jsonNodeschema.get("components")).set("securitySchemes", securityScheme);
//				System.out.println(jsonNodeschema.getNodeType());
				response.put("code", "0");
				response.put("Schemas", jsonNodeschema);
				return response;
			}
			catch(Exception e) {
				
//				System.out.println(schema);

				System.out.println(schemaPropName);
				
				response.put("Status", "failure");
				response.put("method name", schemaPropName);
				response.put("code", "1");
				response.put("message", e.getMessage());
			}
		}
		else {
			response.put("Status", "failure");
			response.put("code", "1");
			response.put("message", "null from query");
		}
		return response;
	}

	// Recursion method to sub json
	public static void generateSubJson(JsonNode jsonObject, String jsonKey) {

		StringBuffer ReqResStr = new StringBuffer("\"" + jsonKey + "Dtls\":{\"type\":\"object\",\"properties\":{");
		jsonObject.fields().forEachRemaining(key -> {

			String keyName = key.getKey();
			String keyType = key.getValue().getNodeType().toString();
			JsonNode keyValue = key.getValue();
			flag2.put(keyName, false);

			if (keyType.equalsIgnoreCase("OBJECT")) {

				flag2.replace(keyName, true);
				
				SchemaGeneratorImpl.generateSubJson(keyValue, keyName);
			}
			String str = "\"" + keyName + "\":{\"type\":\"" + (Boolean.valueOf(flag2.get(keyName)) ? "array" : "string")
					+ "\"," + (Boolean.valueOf(flag2.get(keyName)) ? "\"items\": {\"$ref\":" : "\"enum\":")
					+ (Boolean.valueOf(flag2.get(keyName)) ? "\"#/components/schemas/" + keyName + "Dtls\"}"
							: "[" + keyValue + "]")
					+ "}";

			ReqResStr.append(str + ",");

		});
		ReqResStr.replace(ReqResStr.length() - 1, ReqResStr.length(), "}}");
		schema.append(ReqResStr + ",");
	}

	// Recursion method to main json
	public static StringBuffer mainIterator(JsonNode json,StringBuffer reqResStr){

		json.fields().forEachRemaining(key -> {
			flag = false;
			String keyName = key.getKey();
			String keyType = key.getValue().getNodeType().toString();
			JsonNode keyValue = key.getValue();
			if (keyType.equalsIgnoreCase("OBJECT")) {
				flag = true;
				SchemaGeneratorImpl.generateSubJson(keyValue, keyName);
			}
			String str = "\"" + keyName + "\":{\"type\":\"" + (flag ? "array" : "string") + "\","
					+ (flag ? "\"items\": {\"$ref\":" : "\"enum\":")
					+ (flag ? "\"#/components/schemas/" + keyName + "Dtls\"}" : "[" + keyValue + "]") + "}";

			reqResStr.append(str + ",");
		});
		return reqResStr;
	}
	
	public JsonNode generateSecuritySchema() {
		
		Map<String,Object> securitySchemes = new LinkedHashMap<>();
		Map<String,Object> bearerAuth = new LinkedHashMap<>();
		
		bearerAuth.put("type", "http");
		bearerAuth.put("scheme", "bearer");
		
		securitySchemes.put("BearerAuth", bearerAuth);

		StringBuilder result = new StringBuilder();
		
		try {
			result.append(objectMapper.writeValueAsString(securitySchemes));
			JsonNode jsonNodeschema = objectMapper.readTree(result.toString());
			System.out.println("security schema node "+jsonNodeschema);
			return jsonNodeschema;
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
