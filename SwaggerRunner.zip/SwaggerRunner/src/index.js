// index.mjs
import express from 'express';
import { json } from 'express';
import YAML from 'yamljs';
import swaggerUI from 'swagger-ui-express';
import config from './config.js';
import favicon from 'serve-favicon';
import cors from 'cors';
import path from 'path';
import ejs from 'ejs';
import process from 'process';

const app = express();

// Middleware to parse JSON data
app.use(json());
app.use(cors());
app.use(express.static(path.join(`${process.cwd()}\\src`, 'public')));
app.use(favicon(`${process.cwd()}\\src` + '\\public\\favicon.ico'));
app.set('view engine', 'ejs');
app.engine('ejs', ejs.__express);
app.set('views', path.join(`${process.cwd()}\\src`, 'public'));

app.get('/yaml', function (req, res) {
    res.setHeader('Content-Type', 'application/json');
    //res.send(swaggerSpec);
    res.send(swaggerDocument);
});

const swaggerDocument = YAML.load('./src/openapi3_0.yml');

const swaggerOpts = {
    // By default the Swagger Explorer bar is hidden, to display it pass true
    explorer: true,
    //swaggerUrl: 'http://localhost:8080/apispecs.json',
    swaggerOptions: {
        validatorUrl: null,
        // url: 'http://petstore.swagger.io/v2/swagger.json',
        //url: 'http://localhost:8080/apispecs.json',
        //url: '/',
        //url: 'http://petstore.swagger.io/v2/swagger.json',
        urls: [
            {
                url: 'http://localhost:8080/yaml',
                name: 'Production API Documentation'
            },
            {
                url: 'http://petstore.swagger.io/v2/swagger.json',
                name: 'UAT API Documentation'
            },
            {
                url: 'https://petstore3.swagger.io/api/v3/openapi.json',
                name: 'Test API Documentation'
            }
        ]
    },
    // Hide the default the Swagger Explorer bar - search bar also 
    // customCss: '.swagger-ui .topbar-wrapper .download-url-wrapper {display: none}',
    //customCss: ".swagger-ui .topbar-wrapper img{ content: url('./sf-logo.png'); width: 72px; height: 31px; }",
    //customCss: ".topbar-wrapper img[alt='Swagger UI'], .topbar-wrapper span {visibility: collapse;} .topbar-wrapper .link:after{ content: url('/sf-logo.png'); width: 72px; height: 31px; }",
    // Custom stylesheets as relative file path or url
    customCssUrl: [
        '/styles.css',
        //  'https://example.com/other-custom.css'
    ],
    // To have full control over your HTML you can provide your own javascript file
    //customJs: '/custom.js',
    // To display console message at Browser Developer Tools 
}

//loads swagger page
app.use('/apidocs', swaggerUI.serve, swaggerUI.setup(null, swaggerOpts));
// app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpec, { explorer: true }));
//app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpec, { customCss: ".swagger-ui .topbar { display: none }"}));
// app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(null, {swaggerUrl: './apispecs.json'}));
//app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpec, swaggerOpts));
// app.use('/apidocs', swaggerUI.serve,basicAuth({
//   users: {'008641': ''},
//   challenge: true,
// }) ,swaggerUI.setup(swaggerDocument, swaggerOpts));
//app.use('/apidocs', swaggerUI.serve, swaggerUI.setup(swaggerDocument, swaggerOpts));


app.get('/', function (req, res) {
    // Get an array of flash messages by passing the key to req.flash()
    //res.render('index', { title: 'sundaraminfotech.in', message: req.flash('info') });
    res.render('index', { title: 'sundaraminfotech.in', message: `This program demonstrates many features` });
  });

// Start the server
app.listen(config.APP.PORT, config.APP.HOST, () => {
    console.log(`Server is running on http://${config.APP.HOST}:${config.APP.PORT}`);
});