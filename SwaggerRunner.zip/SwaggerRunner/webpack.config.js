import path from 'path';
import nodeExternals from 'webpack-node-externals';

export default {
  entry: './src/index.js', // Replace with your entry file
  output: {
    path: path.resolve('C:\\Ranjith\\Projects\\React\\SwaggerRunner\\dist'),
    filename: 'webpackBuild.cjs',
  },
  mode: 'development',
  externals: [nodeExternals()],
  module: {
    rules: [
      {
        test: /\.ya?ml$/,
        use: 'yaml-loader',
      },
    ],
  },
};
