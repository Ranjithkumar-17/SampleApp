package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.Author;
import com.app.entity.Employee;
import com.app.service.AuthorService;
import com.app.service.EmployeeService;

@RestController
@RequestMapping("api")
public class EmployeeController {

	@Autowired
	EmployeeService empService;
	
	@Autowired
	AuthorService authorService;

	//OneToOne Relationship Example
	@GetMapping("v1/employees")
	ResponseEntity<List<Employee>> getAllEmp() {
		List<Employee> emp = empService.fetchAllemp();
		return new ResponseEntity<List<Employee>>(emp, HttpStatus.OK);

	}
	
	//OneToMany Relationship Example
		@GetMapping("v1/author")
		ResponseEntity<List<Author>> getAllAuthor() {
			List<Author> author = authorService.fetchAllAuthors();
			System.out.println(author);
			return new ResponseEntity<List<Author>>( HttpStatus.OK);

		}

}
