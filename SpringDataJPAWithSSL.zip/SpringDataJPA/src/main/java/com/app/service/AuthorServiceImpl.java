package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.Author;
import com.app.repo.AuthorRepo;

@Service
public class AuthorServiceImpl implements AuthorService {

	@Autowired
	AuthorRepo repo;
	
	@Override
	public List<Author> fetchAllAuthors() {
		return repo.findAll();
	}

}
