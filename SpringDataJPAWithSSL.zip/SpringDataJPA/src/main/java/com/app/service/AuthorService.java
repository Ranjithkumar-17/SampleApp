package com.app.service;

import java.util.List;

import com.app.entity.Author;

public interface AuthorService {
	List<Author> fetchAllAuthors();
}
