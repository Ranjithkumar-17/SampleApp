// import express from 'express';
// import YAML from 'yamljs';
// import swaggerUI from 'swagger-ui-express';
// const app = express();

// // Load yaml file
// const TestTomcatYml = YAML.load('D:\\Project\\Documents\\SwaggerCentralLibrary\\YamlFile\\Test_Tomcat_ContextSeperated.yml');

// app.get('/Test_Tomcat', function (req, res) {
//     res.setHeader('Content-Type', 'application/json');
//     res.send(TestTomcatYml);
// });

// const swaggerOpts = {
//     explorer: true,
//     swaggerOptions: {
//         validatorUrl: null,
//         urls: [
//             {
//                 url: 'http://localhost:4000/Test_Tomcat',
//                 name: 'Test Tomcat API'
//             }
//         ]
//     },
//     customCssUrl: ['styles.css']
// }

// app.use(express.static('public'));
import express from 'express';
import { json } from 'express';
import YAML from 'yamljs';
import swaggerUI from 'swagger-ui-express';
import cors from 'cors';
import path from 'path';
import ejs from 'ejs';
const app = express();
app.use(json());
app.use(cors());
app.use(express.static('publics'));
app.set('view engine', 'ejs');
app.engine('ejs', ejs.__express);
app.set('views', path.join('public'));

// // Load yaml file
const TestTomcatYml = YAML.load('D:\\Project\\Documents\\SwaggerCentralLibrary\\YamlFile\\Test_Tomcat_ContextSeperated.yml');

app.get('/Test_Tomcat', function (req, res) {
    res.setHeader('Content-Type', 'application/json');
    res.send(TestTomcatYml);
});

const swaggerOpts = {

    explorer: true,
    swaggerOptions: {
        validatorUrl: null,
        urls: [
                        {
                            url: 'http://localhost:4000/Test_Tomcat',
                            name: 'Test Tomcat API'
                        }
                    ]
    },
    customCssUrl: [
        '/styles.css',
    ]
}

app.use('/apidocs', swaggerUI.serve, swaggerUI.setup(null, swaggerOpts));

app.listen(4000, () => {
    console.log("Application running on http://localhost:4000");
});
