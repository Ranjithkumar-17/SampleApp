import path from 'path';

export default {  
  entry: './src/index.js',
  output: {
    filename: 'bundle.js',
    path: path.resolve('C:\\Ranjith\\Projects\\React\\rate-limit-app with build\\rate-limit-app\\dist'),
    libraryTarget: 'module', // Set the library target to 'module'
    chunkFormat: 'module',
  },
  experiments: {
    outputModule: true, // Enable the 'outputModule' experimental feature
  },
  mode: 'development', // Add this line
  target: 'node', // Add this line
  module: {
    rules: [
      {
        test: /\.js$/, // Match JavaScript files
        // exclude: /node_modules/, // Exclude node_modules
      },
    ],
  },
};
