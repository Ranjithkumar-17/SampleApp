import fetchSampleData from './books.service.js';
import { logger, getFileName } from '../../helpers/logger.js';
import OS from 'os';
import IP from 'ip';
import moment from 'moment';

const getBooks = (req, res, next) => {
  //logger.start('getBooks', 'info'); 
  let startTime = moment();
  try {
    const books = fetchSampleData();

    let clientHostName = OS.hostname();
    let clientIpAddress = IP.address();
    //let clientIpAddress = (req.headers["X-Forwarded-For"] || req.headers["x-forwarded-for"] || '').split(',')[0] || req.connection.remoteAddress;
    logger.log("info", `${getFileName()} - client host address is: ${clientHostName}`);
    logger.log("info", `${getFileName()} - client ip address is: ${clientIpAddress}`);

    res.jsend.success(books);

  } catch (error) {
    next(error);
  } finally {
    // let diff = logger.stop_ms('getBooks');
    // logger.log('info',`Time taken for getBooks() ${diff} milliseconds`);
    logger.log('info',`${getFileName()} - Time taken for getBooks() is ${moment().diff(startTime, 'milliseconds')} millis`, {fileName:`${getFileName()}`,});
  }
};

export default getBooks;