import fs from 'fs';

const pathToJsonFile = 'src/api/books/books.json';
const fetchSampleData = () => {
  let rawdata = fs.readFileSync(pathToJsonFile);
  let books = JSON.parse(rawdata);
  return books;
};

export default fetchSampleData;