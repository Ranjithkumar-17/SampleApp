// Importing the express-rate-limit dependency
import rateLimit from "express-rate-limit";

// Calling the ratelimiter function with its options
// max: Contains the maximum number of requests
// windowsMs: Contains the time in milliseconds to receive max requests
// message: message to be shown to the user on rate-limit
const rateLimiterUsingThirdParty = rateLimit({
   max: 10,
   windowMs: 1 * 60 * 1 * 1000, // 24 * 60 * 60 * 1000   24 hrs in milliseconds
   message: `You have exceeded the 10 requests in 1 hrs limit!`,
   standardHeaders: true,
   legacyHeaders: false,
});

module.exports={
    rateLimiterUsingThirdParty,
}
