import pkjson from '../package.json' assert {type: 'json'};
import { logger, getFileName } from './helpers/logger.js';

const options = {
  openapi: '3.0.0',
  // Like the one described here: https://swagger.io/specification/#infoObject
  info: {
    title: `API Central Library`,
    version: `${pkjson.version}`,
    // description: 'API documentation for Books',
    termsOfService: "http://swagger.io/terms/",
    contact: {
      name: ': 🚨Delivery Excellance',
      email: 'rkrish@sundaraminfotech.in',
    },
    // license: {
		// 	"name": "Apache 2.0",
		// 	"url": "http://www.apache.org/licenses/LICENSE-2.0.html"
		// },
  },
  externalDocs: {
		description: "Find out more about Swagger",
		url: "http://swagger.io"
	},
  servers: [
    {
      url: "{scheme}://apiservicedev:{port}/{appcontext}",
      description: "Common Development API Services",
      variables: {
        scheme:{
          enum: [ "http", "https" ],
          default: "http"
        },
        port: {
          enum: [ "80", "443", "8000", "8010", "8070", "8082", "8086", "9090" ],
          default: "9090",
          description: "Select your server port here"
        },
        appcontext: {
          default: "anycontexthere",
          description: "Enter your app context name here"
        },
      }
    },
    {
      url: "{scheme}://apiservice:{port}/{appcontext}",
      description: "Common Production API Services",
      variables: {
        scheme:{
          enum: [ "http", "https" ],
          default: "http"
        },
        port: {
          enum: [ "80", "443", "8000", "8010", "8070", "8082", "8086", "9090" ],
          default: "8000",
          description: "Select your server port here"
        },
        appcontext: {
          enum: [ "dmsimageprocess", "msdapiservice", "pancardcollapi", "sfapiexistingexposurenote", "sfapiexposurenote", "sfapiservice", "sfdealerenq", "sfexternalapi", "sfexternalenq", "sfvisitlogapi", "sfwhatsappapi", "smeapiservice" ],
          default: "sfapiservice",
          description: "Enter your app context name here"
        },
      }
    },
    {
      url: "http://vrudevadmgrsrvc.sfl.ad:{port}/{appcontext}",
      description: "Vruddhi Application Development API Services",
      variables: {
        port: {
          enum: [ "9091" ],
          default: "9091",
          description: "Select your server port here"
        },
        appcontext: {
          enum: [ "vruddhi/sfapi", "vruddhi/schedule" ],
          default: "vruddhi/sfapi",
          description: "Enter your app context name here"
        },
      }
    },
    {
      url: "https://vruddhiservice.sfl.in/{appcontext}",
      description: "Vruddhi Application Production API Services",
      variables: {
        appcontext: {
          enum: [ "vruddhi/sfapi" ],
          default: "vruddhi/sfapi",
          description: "Enter your app context name here"
        },
      }
    },
    {
      url: "http://smecoreapiuat:{port}/{appcontext}",
      description: "SME Application UAT API Services",
      variables: {
        port: {
          enum: [ "80" ],
          default: "80",
          description: "Select your server port here"
        },
        appcontext: {
          enum: [ "firstfillapi", "tebasapi", "sfoneappapi", "sfexternalapi", "poddocument", "sfvruddhiapi", "sfapiservice" ],
          default: "firstfillapi",
          description: "Enter your app context name here"
        },
      }
    },
    {
      url: "https://portal.sfl.in/{appcontext}",
      description: "Customer Portal Production API Services",
      variables: {
        appcontext: {
          enum: [ "oplogin", "opcommon", "openquiry", "optrans" ],
          default: "openquiry",
          description: "Enter your app context name here"
        },
      }
    },
    {
      url: "https://mobapps.sfl.in/{appcontext}",
      description: "Mobile Apps Production API Services",
      variables: {
        appcontext: {
          enum: [ "OnlineSundaramService", "psexternalenquiry" ],
          default: "OnlineSundaramService",
          description: "Enter your app context name here"
        },
      }
    }
   ],
  tags: [{
    name: "Asset",
    description: "Everything about your Books",
    externalDocs: {
      description: "Find out more",
      url: "http://swagger.io"
    }
  },
  {
    name: "books",
    description: "Access to all books",
    externalDocs: {
      description: "Find out more about our store",
      url: "http://swagger.io"
    }
  }],
  paths: {
    "/api/v1/getAssetDtls": {
      get: {
        tags: [
          "Asset"
        ],
        summary: 'xx',
        description: 'yyyyy',
        security: [
          {
            "ApiKeyAuth": []
          }
        ]
      }
    },
    "/api/master/v1/findAssetTypeDtls": {
      get: {
        tags: [
          "Asset"
        ],
        summary: 'xx',
        description: 'yyyyy',
        security: [
          {
            "ApiKeyAuth": []
          }
        ]
      }
    }
  },
  components: {
    securitySchemes: {
      BasicAuth: {
        type: 'http',
        scheme: 'basic'
      },
      BearerAuth: {
        type: 'http',
        scheme: 'bearer'
      },
      ApiKeyAuth: {
        type: 'apiKey',
        in: 'header',
        name: 'X-API-Key'
      },
      OpenID: {
        type: 'openIdConnect',
        openIdConnectUrl: 'https://example.com/.well-known/openid-configuration'
      },
      OAuth2: {
        type: 'oauth2',
        flows: {
          authorizationCode: {
            authorizationUrl: 'https://example.com/oauth/authorize',
            tokenUrl: 'https://example.com/oauth/token',
            scopes: {
              read: 'Grants read access',
              write: 'Grants write access',
              admin: 'Grants access to admin operations'
            }
          }
        }
      }
    }
  }
};

const swaggerSpec = JSON.parse(JSON.stringify(options));
//logger.log('info', `swaggerSpec ${JSON.stringify(swaggerSpec)}`);

export default swaggerSpec;