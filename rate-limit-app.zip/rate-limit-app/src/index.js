import bodyParser from 'body-parser';
import express from 'express';
import basicAuth from 'express-basic-auth';

import cors from 'cors';
import jsend from 'jsend';
import ejs from 'ejs';
import path from 'path';
import favicon from 'serve-favicon';
import process from 'process';
//import swaggerJSDoc from 'swagger-jsdoc';
import swaggerUI from 'swagger-ui-express';
import YAML from 'yamljs';

import { logger, getFileName } from './helpers/logger.js';
import errorHandler from './middleware/errorHandler.js';
import booksRouter from './api/books/books.router.js';

import config from './config.js';
import { get } from 'http';
import swaggerSpec from './apispecs.js';

// Essential globals
const app = express();

//  Initialize global application middlewares
app.use(cors());
app.use(
  bodyParser.urlencoded({
    extended: true
  })
);
app.use(
  bodyParser.json({
    type: 'application/json'
  })
);
app.use(jsend.middleware);

// uncomment after placing your favicon in /public
app.use(express.static(path.join(`${process.cwd()}\\src`, 'public')));
app.use(favicon(`${process.cwd()}\\src` + '\\public\\favicon.ico'));

console.log(`${process.cwd()}\\src`);

// // Initialize Global Error Handlers
app.use(errorHandler);
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send(`Something broke! ${err.stack}`);
})

app.set('view engine', 'ejs');
app.engine('ejs', ejs.__express);
// Set 'views' directory for any views 
// being rendered res.render()
app.set('views', path.join(`${process.cwd()}\\src`, 'public'));

// To avoid GET /favicon.ico HTTP/1.1" 304 error
//app.get('/favicon.ico', (req, res) => res.status(204).end());

app.get('/flash', function (req, res) {
  // Set a flash message by passing the key, followed by the value, to req.flash().
  req.flash('info', 'Flash is back!')
  res.redirect('/');
});

app.get('/apispecs', function (req, res) {
  res.setHeader('Content-Type', 'application/json');
  //res.send(swaggerSpec);
  res.send(swaggerDocument);
});


// tomcat api
app.get('/tomcatapi', function (req, res) {
  res.setHeader('Content-Type', 'application/json');
  //res.send(swaggerSpec);
  res.send(tomcatSwaggerDocument);
});

logger.info(`loading yaml file to swaggerDocument starts-here`);

const swaggerDocument = YAML.load(`${process.cwd()}\\src\\openapi3_0.yml`);
const tomcatSwaggerDocument = YAML.load(`${process.cwd()}\\src\\test_tomcat.yml`);

logger.info(`loading yaml file to swaggerDocument ends-here`);

const swaggerOpts = {
  // By default the Swagger Explorer bar is hidden, to display it pass true
  explorer: true,
  //swaggerUrl: 'http://localhost:8080/apispecs.json',
  swaggerOptions: {
    validatorUrl: null,
    // url: 'http://petstore.swagger.io/v2/swagger.json',
    //url: 'http://localhost:8080/apispecs.json',
    //url: '/',
    //url: 'http://petstore.swagger.io/v2/swagger.json',
    urls: [
      {
        url: 'http://192.168.9.17:8080/apispecs',
        name: 'Production API Documentation'
      },
      {
        url: 'http://192.168.9.17:8080/tomcatapi',  
        name: 'Tomcat API Documentation'
      },
      {
        url: 'http://petstore.swagger.io/v2/swagger.json',
        name: 'UAT API Documentation'
      },
      {
        url: 'https://petstore3.swagger.io/api/v3/openapi.json',
        name: 'Test API Documentation'
      }
    ]
  },
  // Hide the default the Swagger Explorer bar - search bar also 
  // customCss: '.swagger-ui .topbar-wrapper .download-url-wrapper {display: none}',
  //customCss: ".swagger-ui .topbar-wrapper img{ content: url('./sf-logo.png'); width: 72px; height: 31px; }",
  //customCss: ".topbar-wrapper img[alt='Swagger UI'], .topbar-wrapper span {visibility: collapse;} .topbar-wrapper .link:after{ content: url('/sf-logo.png'); width: 72px; height: 31px; }",
  // Custom stylesheets as relative file path or url
  customCssUrl: [
    '/styles.css',
    //  'https://example.com/other-custom.css'
  ],
  // To have full control over your HTML you can provide your own javascript file
  //customJs: '/custom.js',
  // To display console message at Browser Developer Tools 
  //customJsStr: [`console.log("Copyright(c) 2023 Reserved by Sundaram Infotech Solutions")`],
};

app.use('/apidocs', swaggerUI.serve, swaggerUI.setup(null, swaggerOpts));
// app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpec, { explorer: true }));
//app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpec, { customCss: ".swagger-ui .topbar { display: none }"}));
// app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(null, {swaggerUrl: './apispecs.json'}));
//app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpec, swaggerOpts));
// app.use('/apidocs', swaggerUI.serve,basicAuth({
//   users: {'008641': ''},
//   challenge: true,
// }) ,swaggerUI.setup(swaggerDocument, swaggerOpts));
//app.use('/apidocs', swaggerUI.serve, swaggerUI.setup(swaggerDocument, swaggerOpts));

let swaggerHtml = swaggerUI.generateHTML(swaggerDocument, swaggerOpts)
//logger.info(`swaggerHtml \n ${swaggerHtml}`);
app.get('/apihtml', (req, res) => { res.send(swaggerHtml) });


/**
 * @openapi
 * /:
 *   get:
 *     description: Welcome to swagger-jsdoc!
 *     responses:
 *       200:
 *         description: Returns a mysterious string.
 */
app.get('/', function (req, res) {
  // Get an array of flash messages by passing the key to req.flash()
  //res.render('index', { title: 'sundaraminfotech.in', message: req.flash('info') });
  res.render('index', { title: 'sundaraminfotech.in', message: `This program demonstrates many features` });
});

/**
 * @openapi
 * /books:
 *   get:
 *     description: To get list of Books 
 *     responses:
 *       200:
 *         description: Returns a list of books available in the store.
 */
app.use('/books', booksRouter);

// It's easier to deal with complex paths.
// This resolves to: appdir/dashboard/
const dataDir = path.resolve(`${process.cwd()}${path.sep}dashboard`);

// This resolves to: appdir/dashboard/templates/
// which is the folder that stores all the internal template files.
const templateDir = path.resolve(`${dataDir}${path.sep}templates`);

// logger.log("info", `${process.cwd()}${path.sep}dashboard`);
// logger.log("info", `${dataDir}${path.sep}templates`);

app.listen(config.APP.PORT, config.APP.HOST, () => {
  //process.stdout.write('\033c');
  logger.info(`${getFileName()} - Starting Watchtower on  port ${config.APP.PORT}`);

  logger.info(`${getFileName()} - Server is running on port ${config.APP.PORT}`);
  logger.info(`${getFileName()} - Node running version is ${process.versions.node}`);
  logger.info(`${getFileName()} - Application available under URL http://${config.APP.HOST}:${config.APP.PORT}`);

  logger.warn(`${getFileName()} - This is the message using logger.warn`);
  logger.error(`${getFileName()} - This is the message using logger.error`);
  logger.log("debug", `${getFileName()} - This is the message using logger.log`);

});

process.on('unhandledRejection', (reason, promise) => {
  throw reason;
});

process.on('uncaughtException', (error) => {
  logger.error(`Uncaught Exception: ${500} - ${error.message}, Stack: ${error.stack}`);
  //process.exit(1);
});

process.on('SIGINT', () => {
  logger.info(' Alright! Bye bye!');
  process.exit();
});
