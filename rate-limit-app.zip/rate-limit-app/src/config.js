import dotnet from 'dotenv';

dotnet.config();

let runMode = `| NODE_ENV is running under ${process.env.NODE_ENV} mode |`;
let boxSize = "+" + '='.repeat(runMode.length - 2) + "+";
console.log(boxSize);
console.log(runMode);
console.log(boxSize);

const loadEnvVariable = envName => {
  const env = process.env[envName];
  if (env == null) {
    throw new Error(`Environment variable => ${envName} is undefined.`);
  }
  return env;
};

const config = {
  APP: {
    NAME: loadEnvVariable('APP_NAME'),
    DESC: loadEnvVariable('APP_DESC'),
    HOST: loadEnvVariable('APP_HOST'),
    PORT: loadEnvVariable('APP_PORT') || 8080,
    ENV: process.env.NODE_ENV
  },
  DB: {
    URL: loadEnvVariable('MONGODB_URI'),
  }
};
export default config;

