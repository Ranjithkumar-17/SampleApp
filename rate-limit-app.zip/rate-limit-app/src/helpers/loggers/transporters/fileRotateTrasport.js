import { format, transports } from 'winston';
import 'winston-daily-rotate-file';
import config from '../../../config.js';

const { combine, timestamp, label, colorize, align, printf, prettyPrint, errors } = format;
const APP_NAME = (config.APP.NAME).split(" ").join("-");
// 0 - error,  1 - warn,  2 - Info,  3 - http,  4 - verbose, 5 - debug,  6 - silly
const LOGGER_LEVEL = "info";

// DailyRotateFile func()
const fileRotateTransport = new transports.DailyRotateFile({
  filename: `logs/${APP_NAME}-%DATE%.log`,
  auditFile: `logs/${APP_NAME}-auditlog.json`,
  datePattern: "YYYY-MM-DD-HH",
  zippedArchive: true,
  maxSize: '5k',   //'20m',   // 'k', 'm', or 'g'
  maxFiles: "14d",
  level: LOGGER_LEVEL
});

// fired when a log file is created
fileRotateTransport.on('new', (filename) => { });
// fired when a log file is rotated
fileRotateTransport.on('rotate', function (oldFilename, newFilename) {
  console.log(`oldFilename ${oldFilename}`);   // oldFilename logs\applog-2023-08-30.log.1
  console.log(`newFilename ${newFilename}`);   // newFilename logs\applog-2023-08-30.log.2
});
// fired when a log file is archived
fileRotateTransport.on('archive', (zipFilename) => { 
  console.log(`file archive is ${zipFilename}`);
});
// fired when a log file is deleted
fileRotateTransport.on('logRemoved', (removedFilename) => { 
  console.log(`log file removed is ${removedFilename}`);
});

export default fileRotateTransport;
