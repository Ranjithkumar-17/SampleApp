import { format, transports, addColors } from 'winston';
import { v4 as uuidv4 } from "uuid";
import path from 'path';
import { get, parse } from 'stack-trace';

import config from '../../../config.js';

const { combine, label, colorize, align, printf, prettyPrint, errors, timestamp } = format;
const APP_NAME = (config.APP.NAME).split(" ").join("-");
const LOGGER_LEVEL = "silly";
let id = uuidv4();

// Using the printf format.
const devLogFormat = printf( (info) => {
  return `[${info.timestamp}] 🏷️  ${info.fileName || info.label} - [${info.level}]: ${info.stack || info.message}`;
  // return `${info.level === "error" ? "❌" : "✅"} ${info.level}: ${info.message} ${info.level === "error" ? "| 🕗 " + timestamp.substring(0, 19) : ""} ${"\n"} ${info.level === "error" ? info.stack : ""}`;
});

const colors = {
  error: 'black redBG',
  warn: 'black yellowBG',
  info: 'black greenBG',
  verbose: 'black cyanBG',
  debug: 'black blueBG',
  silly: 'black magentaBG'
}
addColors(colors);

const consoleTransport = new transports.Console({
  level: LOGGER_LEVEL,
  format: combine(
    errors({ stack: true }),
    label({ label: APP_NAME }),
    timestamp({
      format: "DD-MM-YYYY HH:mm:ss SSS",
    }),
    colorize({ all: true }),
    devLogFormat,
    //align(),
    //format.cli(),
  ),
}); 

export default consoleTransport;
