import { createLogger, format, transports } from 'winston';
import fileRotateTransport from './transporters/fileRotateTrasport.js';

import 'winston-daily-rotate-file';
import config from '../../config.js';

const { combine, timestamp, label, colorize, align, printf, prettyPrint, errors } = format;
const APP_NAME = (config.APP.NAME).split(" ").join("-");

// Using the printf format.
// const prodLogFormat = printf(({ level, message, label, timestamp }) => {
//   return `${timestamp} [${label}] ${level}: ${message}`;
// });
const prodLogFormat = printf(info => {
  return `[${info.timestamp}] ${info.label} - [${info.level}]: ${info.stack || info.message}`;
});

const buildProdLogger = createLogger({
  format: combine(
    errors({ stack: true }),
    label({ label: APP_NAME }),
    timestamp({
      format: "DD-MM-YYYY HH:mm:ss SSS",
    }),
    //align(),
    // prodLogFormat,
    format.json(),     // This must be uncommented to write log in json format
    //prettyPrint(),
  ),
  defaultMeta: { service: 'user-service' },
  transports: [
    fileRotateTransport
  ], 
  exceptionHandlers: [
    new transports.File({ filename: `logs/${APP_NAME}-exceptions.log` }),
  ],
  rejectionHandlers: [
    new transports.File({ filename: `logs/${APP_NAME}-rejections.log` }),
  ],
  exitOnError: false // do not exit on handled exceptions
});

export default buildProdLogger;
