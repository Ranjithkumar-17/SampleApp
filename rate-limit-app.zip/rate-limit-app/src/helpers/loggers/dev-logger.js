import { createLogger, format } from 'winston';
import fileRotateTransport from './transporters/fileRotateTrasport.js';
import consoleTransport from './transporters/consoleTransport.js';
import config from './../../config.js';

const APP_NAME = (config.APP.NAME).split(" ").join("-");
const { combine, timestamp, label, colorize, align, printf, prettyPrint, errors } = format;
const prodLogFormat = printf(info => {
  return `[${info.timestamp}] ${info.label} - [${info.level}]: ${info.stack || info.message}`;
});

const buildDevLogger = createLogger({
  format: combine(
    // format(function (info) {
    //   console.log(`{ reason: ${info.label}, promise: ${info.fileName} }`);
    //   return info;
    // })(),
    errors({ stack: true }),
    label({ label: APP_NAME }),
    timestamp({
      format: "DD-MM-YYYY HH:mm:ss SSS",
    }),
    //align(),
    prodLogFormat,
    //format.json(),
    //prettyPrint(),
  ),
  transports: [
    fileRotateTransport,
    consoleTransport,
  ],
  exitOnError: false // do not exit on handled exceptionsn
});

export default buildDevLogger;
