import config from '../config.js';
import buildDevLogger from './loggers/dev-logger.js';
import buildProdLogger from './loggers/prod-logger.js';
import { get, parse } from 'stack-trace';

let APP_NAME = (config.APP.NAME).split(" ").join("-");
let logger = null;
if (config.APP.ENV === 'development') {
  logger = buildDevLogger;
} else {
  logger = buildProdLogger;
}

// let childLogger = logger.child({ requestId: 'f9ed4675f1c53513c61a3b3b4e25b4c0' });
// childLogger.info('Info message');

// logger.transports[1].on('logged', function (info) {
//   // `info` log message has now been logged
//   console.log(`Hi krishnamurthy - ${info.message}`);
// });

// dynamically change log level
//logger.transports.console.level = 'info'; 

const getFileName = function() {
  // parse(new Error())[0].getFileName()
  return get()[1].getFileName().split("/").pop();
}

export { logger, getFileName };

