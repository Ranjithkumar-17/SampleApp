// Importing the express dependency
import express from "express";

// Importing the express-rate-limit dependency
import rateLimit from "express-rate-limit";

// Storing the express function in variable application
const applicaion = express();

// Calling the ratelimiter function with its options
// max: Contains the maximum number of requests
// windowsMs: Contains the time in milliseconds to receive max requests
// message: message to be shown to the user on rate-limit
const limiter = rateLimit({
   max: 10,
   windowMs: 1 * 60 * 1 * 1000, // 24 * 60 * 60 * 1000   24 hrs in milliseconds
   message: `You have exceeded the 10 requests in 1 hrs limit!`,
   standardHeaders: true,
   legacyHeaders: false,
});

// Adding the rate-limit function to the express middleware so
// that each requests passes through this limit before executing
applicaion.use(limiter);

let hitCount = 0;
// GET route for handling the user requests
applicaion.get("/", (req, res) => {
    hitCount = hitCount +1;
    console.log (`api called from ip ${req.ip} -> ${hitCount}`);
   res.status(200).json({
      status: "SUCCESS",
      message: "Welcome to TutorialsPoint !"
   });
});

// Server Setup
const port = 8000;
applicaion.listen(port, () => {
   console.log(`app is running on port ${port}`);
});