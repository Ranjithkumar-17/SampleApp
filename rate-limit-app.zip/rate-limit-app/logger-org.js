import { createLogger, format, transports } from 'winston';
import { config } from './src/config';
import "winston-daily-rotate-file";
import 'winston-timer';

const { combine, timestamp, label, colorize, align, printf, prettyPrint  } = format;
const APP_NAME = (config.APP.NAME).split(" ").join("-");
const LOGGER_LEVEL = config.APP.ENV === "production" ? "error" : "debug";

// Using the printf format.
const customFormat = printf(({ level, message, label, timestamp }) => {
  return `${timestamp} [${label}] ${level}: ${message}`;
});

// DailyRotateFile func()
const fileRotateTransport = new transports.DailyRotateFile({
  filename: `logs/${APP_NAME}-%DATE%.log`,
  datePattern: "YYYY-MM-DD",
  zippedArchive: true,
  maxSize: '5k',   //'20m',   // 'k', 'm', or 'g'
  maxFiles: "14d",
  level: LOGGER_LEVEL
});

fileRotateTransport.on('rotate', function(oldFilename, newFilename) {
  // do something fun
  console.log(`oldFilename ${oldFilename}`);   // oldFilename logs\applog-2023-08-30.log.1
  console.log(`newFilename ${newFilename}`);   // newFilename logs\applog-2023-08-30.log.2
});

const logFormat = printf(info => {
  return `${info.timestamp} [${info.level}]: ${info.message}`;
});

// instantiate a new Winston Logger
const logger = createLogger({
  //level: "debug",
  // format: combine(
  //   label({ label: CATEGORY }),
  //   timestamp({
  //     format: "MMM-DD-YYYY HH:mm:ss",
  //   }),
  //   prettyPrint()
  // ),
  format: combine(
      colorize({ all: true }), 
      label({ label: APP_NAME }), 
      timestamp({
        format: "DD-MM-YYYY HH:mm:ss SSS",
      }),
      align(),
      customFormat,
      //format.cli(),
      //format.json()
  ),
  // Console, File, Http, Stream
  // transports: [new transports.Console(), new transports.File({ filename: 'logs/applog.log'})],
  transports: [
    fileRotateTransport, 
    new transports.Console({
      level: 'debug',
      timestamp:true,
      prettyPrint: true,
      colorize: true,
      silent: false,
      maxsize: 5242880,
    }),
    // new transports.File({ 
    //   level: 'debug',
    //   // Create the log directory if it does not exist
    //   filename: 'logs/appdebug.log'
    // })
  ],
  // exceptionHandlers: [new transports.File({ filename: "logs/exceptions.log" })],
  // rejectionHandlers: [new transports.File({ filename: "logs/rejections.log" })],

  // format: format.combine(format.timestamp(), format.json()),
  // transports: [
    // new transports.Console({
    //   format: combine(format.colorize(), logFormat)
    // }),
    // 0 - error,  1 - warn,  2 - Info,  3 - http,  4 - verbose, 5 - debug,  6 - silly
    // level: 'debug' means to cover 0 to 5
  //   new transports.File({ filename: 'logs/applog.log', level: 'debug' }),
  // ],
  exitOnError: false // do not exit on handled exceptionsn
});

winston.timer(logger, { "use_colors": false });

module.exports={
  logger,
};
