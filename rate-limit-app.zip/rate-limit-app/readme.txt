PS C:\reactjs\rate-limit-app> node --watch ./src/index.js

http://localhost:8080/books
http://localhost:8080/flash
http://localhost:8080/

package.json
  "scripts": {
    "dev": "set NODE_ENV=development&&nodemon ./src/index.js",
    "prod": "set NODE_ENV=production&&nodemon ./src/index.js",
    "test": "echo \"Error: no test specified\" && exit 1"
  },

TO run

npm run dev   (or)   node --watch ./src/index

