package in.sis.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.sis.api.entity.OrderEntity;
import in.sis.api.service.OrderService;

import javax.transaction.Transactional;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

//@RestController
//@RequestMapping("api/order")
//public class OrderController {
//
//    @Autowired
//    private OrderService orderService;
//
//
//    @GetMapping("create")
//    @Transactional
//    public Object createOrder() {
//    	
//        return orderService.create();
//    }
//
//    @GetMapping("get")
//    public Object getOrder(Long orderId) {
//    	System.out.println("5");
//        return orderService.get(orderId);
//    }
//
//    @GetMapping("pay")
//    public Object pay(Long orderId) {
//        return orderService.pay(orderId, UUID.randomUUID().toString());
//    }
//
//    @GetMapping("fulfill")
//    public Object fulfill(Long orderId) {
//        return orderService.fulfill(orderId);
//    }
//
//    @GetMapping("cancel")
//    public Object cancel(Long orderId) {
//        return orderService.cancel(orderId);
//    }
//}




@RestController
@RequestMapping("api/order")
public class OrderController {

    @Autowired
    private OrderService orderService;


    @PostMapping("create")
    @Transactional
    public ResponseEntity<CreateOrderResponse> create(@RequestBody OrderEntity orderData) {
  
        OrderEntity order = orderService.create(orderData.getId(), orderData.getName());

    
        CreateOrderResponse response = new CreateOrderResponse();
        response.setId(order.getId());
        response.setName(order.getName());
        response.setMessage("Order created with ID: " + order.getId());

      
        return ResponseEntity.ok(response);
    }


    @GetMapping("get")
    public ResponseEntity<OrderEntity> getOrder(Long orderId) {
        OrderEntity orderEntity = orderService.get(orderId);

        if (orderEntity == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(orderEntity);
    }


    
    @GetMapping("pay")
    public ResponseEntity<Object> pay(@RequestParam("orderId") Long orderId) {
        Object response = orderService.pay(orderId, UUID.randomUUID().toString());
        return ResponseEntity.ok(response);
    }


    
    @PostMapping("fulfill")
    public Object fulfill(@RequestParam Long orderId) {
        try {
            
            orderService.fulfill(orderId);
            
        
            Map<String, String> response = new HashMap<>();
            response.put("message", "Order fulfilled successfully");
            return response;
        } catch (Exception e) {
            
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Order not found");
        }
    }

    
    @PostMapping("/cancel")
    public ResponseEntity<OrderEntity> cancelOrder(
            @RequestParam Long orderId,
            @RequestBody Map<String, String> requestBody) {
        String cancelReason = requestBody.get("reason");
        OrderEntity canceledOrder = orderService.cancel(orderId, cancelReason);
        if (canceledOrder != null) {
            return ResponseEntity.ok(canceledOrder);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}
