package in.sis.api.service;

import in.sis.api.entity.OrderEntity;

public interface OrderService {

    OrderEntity get(Long orderId);

   // OrderEntity create();
    OrderEntity create(Long id, String name);

    OrderEntity pay(Long orderId, String payCode);

    OrderEntity fulfill(Long orderId);

   // OrderEntity cancel(Long orderId);
    OrderEntity cancel(Long orderId, String cancelReason);
}
