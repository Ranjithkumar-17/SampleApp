package in.sis.api.enums;

public enum OrderEvents {
    FULFILL,
    PAY,
    CANCEL;
}
