package in.sis.api.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.statemachine.StateMachine;
import org.springframework.statemachine.config.StateMachineFactory;
import org.springframework.statemachine.persist.StateMachineRuntimePersister;
import org.springframework.statemachine.service.StateMachineService;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import in.sis.api.entity.OrderEntity;
import in.sis.api.entity.PayEntity;
import in.sis.api.enums.OrderEvents;
import in.sis.api.enums.OrderStatus;
import in.sis.api.repo.OrderRepo;
import in.sis.api.repo.PayRepo;

import reactor.core.publisher.Mono;

import java.util.Date;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

   StateMachine<OrderStatus, OrderEvents> currentStateMachine;

   @Autowired
   private OrderRepo orderRepo;

   @Autowired
   private StateMachineService<OrderStatus, OrderEvents> stateMachineService;

   @Autowired
   private StateMachineFactory<OrderStatus, OrderEvents> stateMachineFactory;

   @Autowired
   private StateMachineRuntimePersister<OrderStatus, OrderEvents, String> stateMachineRuntimePersister;

   @Autowired
   private PayRepo payStatusRepository;

   @Override
   public OrderEntity pay(Long orderId, String payCode) {
       StateMachine<OrderStatus, OrderEvents> stateMachine = this.getStateMachine(orderId);
       stateMachine.sendEvent(Mono.just(MessageBuilder.withPayload(OrderEvents.PAY)
               .setHeader("orderId", orderId)
               .setHeader("payCode", payCode)
               .build())).blockLast();

       OrderEntity order = get(orderId);
       order.setStatus(OrderStatus.PAID);
       orderRepo.saveAndFlush(order);

       PayEntity payStatusEntity = new PayEntity();
       payStatusEntity.setOrderId(orderId);
       payStatusEntity.setPayStatus("PAID");
       payStatusRepository.save(payStatusEntity);

       return order;
   }

   @Override
   public OrderEntity get(Long orderId) {
       return orderRepo.findById(orderId).orElseThrow();
   }

   @Override
   public OrderEntity fulfill(Long orderId) {
       StateMachine<OrderStatus, OrderEvents> stateMachine = this.getStateMachine(orderId);
       stateMachine.sendEvent(Mono.just(MessageBuilder.withPayload(OrderEvents.FULFILL)
               .setHeader("orderId", orderId)
               .build())).blockLast();
       return get(orderId);
   }

   @Override
   public OrderEntity cancel(Long orderId, String cancelReason) {
       Optional<OrderEntity> optionalOrder = orderRepo.findById(orderId);
       if (optionalOrder.isPresent()) {
           OrderEntity order = optionalOrder.get();
           order.setStatus(OrderStatus.CANCELLED);
           order.setCancelReason(cancelReason);
           OrderEntity updatedOrder = orderRepo.save(order);
           return updatedOrder;
       } else {
           return null;
       }
   }

   private synchronized StateMachine<OrderStatus, OrderEvents> getStateMachine(Long orderId) {
       String machineId = Long.toString(orderId);
       if (currentStateMachine == null) {
           currentStateMachine = stateMachineService.acquireStateMachine(machineId, false);
           currentStateMachine.startReactively().block();
       } else if (!ObjectUtils.nullSafeEquals(currentStateMachine.getId(), machineId)) {
           stateMachineService.releaseStateMachine(currentStateMachine.getId());
           currentStateMachine.stopReactively().block();
           currentStateMachine = stateMachineService.acquireStateMachine(machineId, false);
           currentStateMachine.startReactively().block();
       }
       return currentStateMachine;
   }

   @Override
   public OrderEntity create(Long id, String name) {
       OrderEntity order = new OrderEntity();
       order.setId(id);
       order.setName(name);
       order.setStatus(OrderStatus.SUBMITTED);
       order.setCreateTime(new Date().toInstant());
       return orderRepo.saveAndFlush(order);
   }
}
