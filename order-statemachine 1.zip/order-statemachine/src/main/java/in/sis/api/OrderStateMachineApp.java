package in.sis.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = {"in.sis.api.entity"})
public class OrderStateMachineApp {

    public static void main(String[] args) {
 
        SpringApplication.run(OrderStateMachineApp.class, args);
        System.out.println("krish");
    }
}
