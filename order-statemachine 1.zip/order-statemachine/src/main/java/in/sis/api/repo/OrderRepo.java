package in.sis.api.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sis.api.entity.OrderEntity;
import in.sis.api.entity.PayEntity;

public interface OrderRepo extends JpaRepository<OrderEntity, Long> {
	
}



