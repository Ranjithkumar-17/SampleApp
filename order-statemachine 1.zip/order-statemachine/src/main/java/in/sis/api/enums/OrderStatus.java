package in.sis.api.enums;

public enum OrderStatus {
    SUBMITTED,
    PAID,
    FULFILLED,
    CANCELLED;
}
