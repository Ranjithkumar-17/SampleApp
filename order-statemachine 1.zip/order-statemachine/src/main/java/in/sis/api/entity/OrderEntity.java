package in.sis.api.entity;

import javax.persistence.*;

import in.sis.api.enums.OrderStatus;

import java.time.Instant;

@Entity(name = "demo_order")
public class OrderEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private OrderStatus status;
    private String name;
    
    public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

	private String cancelReason;
	
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	private Instant createTime;

    public Long getId() {
    	
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public Instant getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Instant createTime) {
        this.createTime = createTime;
    }

	
}
