package in.sis.api.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sis.api.entity.PayEntity;

public interface PayRepo extends JpaRepository<PayEntity, Long> {
}

