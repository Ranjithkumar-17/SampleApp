
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function CreateOrder() {
  const [orderData, setOrderData] = useState({ name: '', orderId: '' });
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    window.history.pushState(null, null, window.location.href);
    window.onpopstate = function () {
      window.history.pushState(null, null, window.location.href);
    };
  }, []);

  const handleCreateOrder = () => {
    fetch('http://localhost:8081/api/order/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(orderData),
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        
        setOrderData(data);
        
        setShowSuccessMessage(true);
        // After a few seconds, hide the success message and navigate
        // setTimeout(() => {
        //   setShowSuccessMessage(false);
        //   navigate(`/view/${data.orderId}`);
        // }, 3000);
      })
      .catch(error => {
        console.error(error);
      });
  };

const handleViewOrder = () => {
 
  navigate(`/view`);
};


  return (
    <div>
      <h2>Create Order</h2>
      <form>
        <label>
          Order Name:
          <input
           style={{margin:'9px',borderRadius:'5px',borderColor:'white',border:'none',outline: 'none' }}
            type="text"
            value={orderData.name}
            onChange={e => setOrderData({ ...orderData, name: e.target.value })}
          />
        </label> 


        <button type="button"  style={{margin:'15px',borderRadius:'20px',borderColor:'white',border:'none',outline: 'none'}}  onClick={handleCreateOrder}>
          Create Order
        </button>
      </form>
      <br/> <br/>
      {showSuccessMessage && (
        <div className="success-message">
          Your order  was successfully created.
         
          <div style={{margin:'15px'}}>
          {orderData.message}
           </div>
        </div>
      )}
      <br/>
      <br/>
<button type="button"  style={{margin:'15px'}}  onClick={handleViewOrder}>
View Order
</button>

    </div>
  );
}

export default CreateOrder;


// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';

// function CreateOrder() {
//   const [orderData, setOrderData] = useState({ name: '', orderId: '' });
//   const [showSuccessMessage, setShowSuccessMessage] = useState(false);
//   const navigate = useNavigate();

//   const handleCreateOrder = () => {
//     fetch('http://localhost:8081/api/order/create', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify(orderData),
//     })
//       .then(response => {
//         if (!response.ok) {
//           throw new Error('Network response was not ok');
//         }
//         return response.json();
//       })
//       .then(data => {
//         // Update the state with the received data
//         setOrderData(data);
//         // Show the success message
//         setShowSuccessMessage(true);
//         // After a few seconds, hide the success message
//         // setTimeout(() => {
//         //   setShowSuccessMessage(false);
//         // }, 3000);
//       })
//       .catch(error => {
//         console.error(error);
//       });
//   };

//   return (
//     <div>
//       <h2>Create Order</h2>
//       <form>
//         <label>
//           Order Name:
//           <input
//             type="text"
//             value={orderData.name}
//             onChange={e => setOrderData({ ...orderData, name: e.target.value })}
//           />
//         </label>
//         <button type="button" onClick={handleCreateOrder}>
//           Create Order
//         </button>
//       </form>
//       {showSuccessMessage && (
//   <div className="success-message">
//     Order (ID: {orderData.orderId}) created successfully.
//     <button onClick={() => navigate(`/view/${orderData.orderId}`)}>View Order</button>
//   </div>
// )}

//     </div>
//   );
// }

// export default CreateOrder;

