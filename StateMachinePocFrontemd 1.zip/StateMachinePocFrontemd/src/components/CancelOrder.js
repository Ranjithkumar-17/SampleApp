// import React, { useState, useEffect } from 'react';
// import { useParams } from 'react-router-dom';

// function CancelOrder() {
//   const { orderId, reason } = useParams();
//   const [cancelReason, setCancelReason] = useState(reason);
//   const [cancellationSuccess, setCancellationSuccess] = useState(false);

//   const handleCancelOrder = () => {
//     const data = {
//       reason: cancelReason,
//     };

//     fetch(`http://localhost:8081/api/order/cancel?orderId=${orderId}`, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify(data),
//     })
//       .then(response => {
//         if (!response.ok) {
//           throw new Error('Network response was not ok');
//         }
//         return response.json();
//       })
//       .then(data => {
//         setCancellationSuccess(true);
//         console.log(data);
//       })
//       .catch(error => {
//         console.error(error);
//       });
//   };

//   return (
//     <div>
//       <h2>Cancel Order</h2>
//       <form>
//         <label>
//           Cancellation Reason:
//           <input
//             type="text"
//             value={cancelReason}
//             onChange={e => setCancelReason(e.target.value)}
//           />
//         </label>
//         <button type="button" onClick={handleCancelOrder}>
//           Cancel Order
//         </button>
//       </form>

//       {cancellationSuccess && (
//         <div className="success-message">
//           Order with ID: {orderId} has been successfully canceled.
//         </div>
//       )}
//     </div>
//   );
// }

// export default CancelOrder;





import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function CancelOrder() {
  const { orderId } = useParams();
  const [inputOrderId, setInputOrderId] = useState('');
  const [cancelReason, setCancelReason] = useState('');
  const [cancellationSuccess, setCancellationSuccess] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    window.history.pushState(null, null, window.location.href);
    window.onpopstate = function () {
      window.history.pushState(null, null, window.location.href);
    };
  }, []);

  const handleCancelOrder = () => {
    const data = {
      orderId: inputOrderId,
      reason: cancelReason,
    };

    fetch(`http://localhost:8081/api/order/cancel?orderId=${inputOrderId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        setCancellationSuccess(true);
        console.log(data);
        // navigate(`/view/${data.orderId}`); 
      })
      .catch(error => {
        console.error(error);
      });
  };
const handleLogout =() =>{
  navigate ('/')
}
  return (
    <div>
      <h2>Cancel Order</h2>
      <form>
        <label>
          Order ID:
          <input
            type="text"
            value={inputOrderId}
            onChange={e => setInputOrderId(e.target.value)}
          />
        </label>
        <label>
          Cancellation Reason:
          <input
           style={{margin:'9px',borderRadius:'5px',borderColor:'white',border:'none',outline: 'none' }}
            type="text"
            value={cancelReason}
            onChange={e => setCancelReason(e.target.value)}
          />
        </label>
        <button type="button"  style={{margin:'15px',borderRadius:'20px',borderColor:'white',border:'none',outline: 'none'}}  onClick={handleCancelOrder}>
          Cancel Order
        </button>
      </form>
      <br/><br/>
      {cancellationSuccess && (
        <div className="success-message">
          Order with ID: {inputOrderId} has been successfully canceled.
        </div>
      )}
<br/><br/><br/>

<button type="button"  style={{margin:'15px',borderRadius:'20px',borderColor:'white',border:'none',outline: 'none'}}  onClick={handleLogout}>
          Logout
         </button>

    </div>

    
  );
}

export default CancelOrder;
