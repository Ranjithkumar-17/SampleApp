// import React, { useState, useEffect } from 'react';
// import { useParams } from 'react-router-dom';

// function FulfillOrder() {
//   const [orderId, setOrderId] = useState('');
//   const [orderDetails, setOrderDetails] = useState(null);


//   const handleFulfill = () => {
//     fetch(`http://localhost:8081/api/order/fulfill?orderId=${orderId}`, {
//       method: 'POST', 
//       headers: {
//         'Content-Type': 'application/json',
//       },
//     })
//       .then(response => {
//         if (!response.ok) {
//           throw new Error('Network response was not ok');
//         }
//         return response.json();
//       })
//       .then(data => {
      
//         alert(`Order with ID ${orderId} has been fulfilled successfully.`);
        
       
//         // navigate('/');
//       })
//       .catch(error => {
//         console.error(error);
//       });
//   };
  
//   return (
//     <div>
//       <h2>Fulfill Order</h2>
//       <form>
//         <label>
//           Fulfillment Details:
//           <input
//             type="number"
//             value={orderId}
//             onChange={e => setOrderId(e.target.value)}
//           />
//         </label>
//         <button type="button" onClick={handleFulfill}>
//           Fulfill Order
//         </button>
//       </form>

//     </div>
//   );
// }

// export default FulfillOrder;


import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';


function FulfillOrder() {
  const [orderId, setOrderId] = useState('');
  const [fulfillmentMessage, setFulfillmentMessage] = useState('');
  const navigate = useNavigate();
  useEffect(() => {
    window.history.pushState(null, null, window.location.href);
    window.onpopstate = function () {
      window.history.pushState(null, null, window.location.href);
    };
  }, []);
  const handleFulfill = () => {
    fetch(`http://localhost:8081/api/order/fulfill?orderId=${orderId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        setFulfillmentMessage(`Order with ID ${orderId} has been fulfilled successfully.`);
      })
      .catch(error => {
        console.error(error);
        setFulfillmentMessage(`Failed to fulfill order with ID ${orderId}`);
      });
  };
const handleLogout =()=>{
  navigate('/create')
}
  return (
    <div>
      <h2>Fulfill Order</h2>
      <form>
        <label>
          Fulfillment Details:
          <input
           style={{margin:'9px',borderRadius:'5px',borderColor:'white',border:'none',outline: 'none' }}
            type="number"
            value={orderId}
            onChange={e => setOrderId(e.target.value)}
          />
        </label>
        <button type="button"   style={{margin:'15px',borderRadius:'20px',borderColor:'white',border:'none',outline: 'none','&:focus': {
    outlineColor: 'Blue'
  }}} onClick={handleFulfill}>
          Fulfill Order
        </button>
      </form>
      <br/><br/>
      {fulfillmentMessage && <p>{fulfillmentMessage}</p>}

      <button type="button"  style={{margin:'15px',borderRadius:'20px',borderColor:'white',border:'none',outline: 'none'}}  onClick={handleLogout}>
          Logout
         </button>
    </div>
  );
}

export default FulfillOrder;
