// import React, { useState, useEffect } from 'react';
// import { useParams } from 'react-router-dom';

// function ViewOrder() {
//   const { orderId } = useParams();
//   const [order, setOrder] = useState(null);

//   useEffect(() => {
   
//     fetch(`http://localhost:8081/api/order/get?${orderId}`)
//       .then(response => response.json())
//       .then(data => {
//         setOrder(data);
//       })
//       .catch(error => {
//         console.error(error);
//       });
//   }, [orderId]);

//   if (!order) {
//     return <div>Loading...</div>;
//   }

//   return (
//     <div>
//       <h2>View Order</h2>
//       <p>Order ID: {order.id}</p>
//       <p>Order Status: {order.status}</p>
//       {/* Display other order details */}
//     </div>
//   );
// }

// export default ViewOrder;
// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// function ViewOrder() {
//   const [orderId, setOrderId] = useState('');
//   const [orderDetails, setOrderDetails] = useState(null);
//   const navigate = useNavigate();
//   const handleViewOrder = () => {
//     fetch(`http://localhost:8081/api/order/get?orderId=${orderId}`)
//       .then(response => {
//         if (!response.ok) {
//           throw new Error('Network response was not ok');
//         }
//         return response.json();
//       })
//       .then(data => {
//         setOrderDetails(data);
//       })
//       .catch(error => {
//         console.error(error);
//       });
//   };

//   const handlePay = () => {
//     navigate(`/pay`);
//   };

//   const handleCancel = () => {
//     navigate(`/cancel`);
//   };

//   return (
//     <div>
//       <h2>View Order</h2>
//       <label>
//         Order ID:
//         <input
//          style={{margin:'9px',borderRadius:'5px',borderColor:'white',border:'none',outline: 'none' }}
//           type="number"
//           value={orderId}
//           onChange={e => setOrderId(e.target.value)}
//         />
//       </label>
//       <button type="button"  style={{margin:'15px',borderRadius:'20px',borderColor:'white',border:'none',outline: 'none'}}  onClick={handleViewOrder}>
//         View Order
//       </button>
//       <br/><br/>
//       {orderDetails && (
//         <div className="order-details">
//           <h3>Order Details</h3>
//           <p>Order ID: {orderDetails.id}</p>
//           <p>Name: {orderDetails.name}</p>
//           <p>Message: {orderDetails.status}</p>
//           <p>Instant Time: {orderDetails.createTime}</p>
//           <button type="button"  style={{margin:'15px'}} onClick={handlePay}>Pay</button>
//           <button type="button"  style={{margin:'15px'}} onClick={handleCancel}>Cancel</button>
//         </div>
//       )}
//     </div>
//   );
// }

// export default ViewOrder;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function ViewOrder() {
  const [orderId, setOrderId] = useState('');
  const [orderDetails, setOrderDetails] = useState(null);
  const navigate = useNavigate();

  // Use the HTML5 History API to prevent going back
  useEffect(() => {
    window.history.pushState(null, null, window.location.href);
    window.onpopstate = function () {
      window.history.pushState(null, null, window.location.href);
    };
  }, []);

  const handleViewOrder = () => {
    fetch(`http://localhost:8081/api/order/get?orderId=${orderId}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        setOrderDetails(data);
      })
      .catch(error => {
        console.error(error);
      });
  };

  const handlePay = () => {
    navigate(`/pay`);
  };

  const handleCancel = () => {
    navigate(`/cancel`);
  };

  return (
    <div>
      <h2>View Order</h2>
      <label>
        Order ID:
        <input
          style={{ margin: '9px', borderRadius: '5px', borderColor: 'white', border: 'none', outline: 'none' }}
          type="number"
          value={orderId}
          onChange={e => setOrderId(e.target.value)}
        />
      </label>
      <button type="button" style={{ margin: '15px', borderRadius: '20px', borderColor: 'white', border: 'none', outline: 'none' }} onClick={handleViewOrder}>
        View Order
      </button>
      <br /><br />
      {orderDetails && (
        <div className="order-details">
          <h3>Order Details</h3>
          <p>Order ID: {orderDetails.id}</p>
          <p>Name: {orderDetails.name}</p>
          <p>Message: {orderDetails.status}</p>
          <p>Instant Time: {orderDetails.createTime}</p>
          <button type="button" style={{ margin: '15px' }} onClick={handlePay}>Pay</button>
          <button type="button" style={{ margin: '15px' }} onClick={handleCancel}>Cancel</button>
        </div>
      )}
    </div>
  );
}

export default ViewOrder;
