import React, { useEffect, useState } from 'react';
 import { useNavigate } from 'react-router-dom';
function ViewOrder() {
  const [orderId, setOrderId] = useState('');
  const [orderDetails, setOrderDetails] = useState(null);
   const navigate = useNavigate();


   useEffect(() => {
    window.history.pushState(null, null, window.location.href);
    window.onpopstate = function () {
      window.history.pushState(null, null, window.location.href);
    };
  }, []);
  const handleViewOrder = () => {


    fetch(`http://localhost:8081/api/order/pay?orderId=${orderId}`)


      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        setOrderDetails(data);
      })
      .catch(error => {
        console.error(error);
      });
  };

 
  const handleCancel = () => {
    navigate(`/cancel`);
  };

  const handlefulfill = () => {
    navigate(`/fulfill`);
  };

  return (
    <div>
      <h2>Pay Order</h2>
      <label>
        Order ID:
        <input
         style={{margin:'9px',borderRadius:'5px',borderColor:'white',border:'none',outline: 'none' }}
          type="number"
          value={orderId}
          onChange={e => setOrderId(e.target.value)}
        />
      </label>
      <button type="button" style={{margin:'15px',borderRadius:'20px',borderColor:'white',border:'none',outline: 'none'}}  onClick={handleViewOrder}>
        Pay Order
      </button>
      <br/><br/>
      {orderDetails && (
        <div className="order-details">
          <h3>Order Details</h3>
          <p>Order ID: {orderDetails.id}</p>
          <p>Name: {orderDetails.name}</p>
          <p>Message: {orderDetails.status}</p>
          <p>Instant Time: {orderDetails.createTime}</p>
          <button type="button" style={{margin:'15px'}} onClick={handleCancel}>Cancel</button>
          <button type="button"  style={{margin:'15px'}} onClick={handlefulfill}>FulfillOrder</button>
        </div>
      )}
    </div>
  );
}

export default ViewOrder;



// import React, { useState, useEffect } from 'react';
// import { useNavigate, useParams } from 'react-router-dom';

// function ViewOrder() {
//   const [orderId, setOrderId] = useState('');
//   const [orderDetails, setOrderDetails] = useState(null);
//   const [alreadyPaidMessage, setAlreadyPaidMessage] = useState('');
//   const navigate = useNavigate();


//   const handleViewOrder = () => {
//     fetch(`http://localhost:8081/api/order/pay?orderId=${orderId}`)
//       .then(response => {
//         if (!response.ok) {
//           throw new Error('Network response was not ok');
//         }
//         return response.json();
//       })
//       .then(data => {
//         if (data.status === 'PAID') {
//           setAlreadyPaidMessage('This order has already been paid.');
//           setOrderDetails(null);
//         } else {
//           setAlreadyPaidMessage('');
//           setOrderDetails(data);
//         }
//       })
//       .catch(error => {
//         console.error(error);
//       });
//   };

//   const handleCancel = () => {
//     navigate(`/cancel`);
//   };

//   const handleFulfill = () => {
//     navigate(`/fulfill`);
//   };

//   return (
//     <div>
//       <h2>Pay Order</h2>
//       <label>
//         Order ID:
//         <input
//           style={{ margin: '9px', borderRadius: '5px', borderColor: 'white', border: 'none', outline: 'none' }}
//           type="number"
//           value={orderId}
//           onChange={e => setOrderId(e.target.value)}
//         />
//       </label>
//       <button type="button" style={{ margin: '15px', borderRadius: '20px', borderColor: 'white', border: 'none', outline: 'none' }} onClick={handleViewOrder}>
//         Pay Order
//       </button>
//       <br /><br />
//       {alreadyPaidMessage && <p>{alreadyPaidMessage}</p>}
//       {orderDetails && (
//         <div className="order-details">
//           <h3>Order Details</h3>
//           <p>Order ID: {orderDetails.id}</p>
//           <p>Name: {orderDetails.name}</p>
//           <p>Message: {orderDetails.status}</p>
//           <p>Instant Time: {orderDetails.createTime}</p>
//           <button type="button" onClick={handleCancel}>Cancel</button>
//           <button type="button" onClick={handleFulfill}>Fulfill Order</button>
//         </div>
//       )}
//     </div>
//   );
// }

// export default ViewOrder;
