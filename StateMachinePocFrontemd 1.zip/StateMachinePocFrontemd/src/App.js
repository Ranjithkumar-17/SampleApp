// import logo from './logo.svg';

// import { Routes } from 'react-router-dom';

// function App() {
//   return (
//    <Routes>
    
//    </Routes>
//   );
// }

// export default App;

import React from 'react';
import { BrowserRouter as Router, Route, Switch, Routes } from 'react-router-dom';
import CreateOrder from './components/CreateOrder';
import ViewOrder from './components/ViewOrder';
import PayOrder from './components/PayOrder';
import FulfillOrder from './components/FulfillOrder';
import CancelOrder from './components/CancelOrder';

function App() {
  return (
    <div>
     <h1 style={{ color: '#DC143C' }}>Order Management System</h1>

      <Router>
        <Routes>
        <Route path="/" element={<CreateOrder/>} />
          <Route path="/create" element={<CreateOrder/>} />
          <Route path="/view" element={<ViewOrder/>} />
          <Route path="/pay" element={<PayOrder/>} />
          
          <Route path="/cancel" element={<CancelOrder/>} />
          <Route path="/fulfill" element={<FulfillOrder/>} />
         
        </Routes>
      </Router>
    </div>
  );
}

export default App;


