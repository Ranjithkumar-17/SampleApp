package in.sis.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FetchApiForPathRepositoryImpl implements FetchApiForPathRepository {

	@Autowired
	JdbcTemplate jdbcTemp;
	
	
	private String libraryquery = "Select * From test.PS_TB_CENTRAL_LIBRARY";
	
	@Override
	public List<Map<String, Object>> fetchApi() {
		
		List<Map<String, Object>> apiList = null;
		
		try{
			apiList = jdbcTemp.queryForList(libraryquery);
//			System.out.println(apiList);
		}
		catch (Exception e) {
			
			System.out.println("Exception "+e.toString());
			return null;
		}
		return apiList;
	}

}
