package in.sis.api.controller;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.sis.api.service.SwaggerYamlGeneratorService;

@RestController
@RequestMapping("api")
public class SwaggerYamlGeneratorController {

	@Autowired
	SwaggerYamlGeneratorService generator;
	
	@PostMapping(value = "v1/swaggerYamlGenerator")
	public Map<String, String> generateYaml() throws IOException {
		return generator.geneateSwagger();
	}
}
