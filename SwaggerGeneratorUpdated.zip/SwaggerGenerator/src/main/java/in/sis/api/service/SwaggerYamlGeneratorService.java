package in.sis.api.service;

import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public interface SwaggerYamlGeneratorService {
	public Map<String,String> geneateSwagger() throws JsonMappingException, JsonProcessingException;
}
