package in.sis.api.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.sis.api.service.HeaderGenertorService;

@RestController
@RequestMapping("api")
public class HeaderGeneratorController {

	@Autowired
	HeaderGenertorService headService;
	
	@PostMapping(value = "v1/headerGenerator")
	public Map<String, Object> generateSwaggerHeader(){		
		return headService.generateHead();
	}
}
