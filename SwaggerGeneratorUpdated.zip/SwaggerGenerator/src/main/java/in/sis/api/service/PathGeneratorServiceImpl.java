package in.sis.api.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator;

import in.sis.api.dao.FetchApiForPathRepository;

@Service
public class PathGeneratorServiceImpl implements PathGeneratorService {

	@Autowired
	FetchApiForPathRepository repo;

	boolean flag = false;
	JsonNode result = null;

	@Override
	public Map<String, Object> generatePaths() {

		Map<String, Object> response = new HashMap<>();
		Map<String, Object> path = new HashMap<>();

		try {

			result = swaggerformat();
			path.put("paths", result);
			response.put("code", "0");
			response.put("Message", "Success");
			response.put("Response", path);

		} catch (IOException e) {
			response.put("code", "1");
			response.put("Message", "Failure");
			response.put("Response", e.getMessage());
		}

		return response;
	}

	private static Map<String, Object> createSecurityObject(String name, List<String> scopes) {
		Map<String, Object> securityObject = new HashMap<>();
		securityObject.put(name, scopes);
		return securityObject;
	}

	public JsonNode swaggerformat() throws IOException {
		String response = null;
		List<Map<String, Object>> apiLsit = repo.fetchApi();
		ObjectMapper objectMapper = new ObjectMapper(
				new YAMLFactory().disable(YAMLGenerator.Feature.WRITE_DOC_START_MARKER));
		StringBuilder result = new StringBuilder();
		for (Map<String, Object> librarydtls : apiLsit) {

			Map<String, Object> swaggerSpec = new HashMap<>();
			List<String> tags = new ArrayList<>();
			Map<String, Object> postOperation = new LinkedHashMap<>();
			Map<String, Object> requestBody = new HashMap<>();
			Map<String, Object> content = new HashMap<>();
			Map<String, Object> ReqSchema = new HashMap<>();
			Map<String, Object> ResSchema = new HashMap<>();
			Map<String, Object> responses = new HashMap<>();
			Map<String, Object> response200 = new HashMap<>();
			Map<String, Object> response400 = new HashMap<>();
			Map<String, Object> response404 = new HashMap<>();
			Map<String, Object> response405 = new HashMap<>();

			List<Map<String, Object>> security = new ArrayList<>();
			Map<String, Object> apiInfo = new HashMap<>();
			Map<String, Object> postOperation1 = new LinkedHashMap<>();
			Map<String, Object> schema1 = new HashMap<>();
			String applicationname = librarydtls.get("APPLICATION_NAME").toString();
			librarydtls.get("API_DESCRIPTION").toString();

			String methodname = librarydtls.get("METHOD_NAME").toString();
			String url = librarydtls.get("SERVICE_URL").toString();

			String afterspl[] = url.split("/" + applicationname, url.length());
			String part1 = afterspl[1];
			System.out.println(part1);

			tags.add(librarydtls.get("APPLICATION_NAME").toString());
			response200.put("description", "Successful operation");
			ResSchema.put("$ref", "#/components/schemas/" + librarydtls.get("METHOD_NAME").toString() + "Response");
			Map<String, Object> content200 = new HashMap<>();

			schema1.put("schema", ResSchema);
			content200.put("application/json", schema1);
			response200.put("content", content200);
			response400.put("description", "Invalid ID supplied");
			response404.put("description", "Pet not found");
			response405.put("description", "Validation exception");
			responses.put("200", response200);
			responses.put("400", response400);
			responses.put("404", response404);
			responses.put("405", response405);
			ReqSchema.put("$ref", "#/components/schemas/" + librarydtls.get("METHOD_NAME").toString() + "Request");
			schema1.put("schema", ReqSchema);
			content.put("application/json", schema1);
			requestBody.put("description", librarydtls.get("API_DESCRIPTION").toString());
			requestBody.put("content", content);
			requestBody.put("required", true);

			postOperation1.put("tags", tags);
			postOperation.put("post", postOperation1);
			postOperation1.put("description", librarydtls.get("API_DESCRIPTION").toString());
			postOperation1.put("operationId", librarydtls.get("METHOD_NAME").toString());
			postOperation1.put("requestBody", requestBody);
			postOperation1.put("responses", responses);

			security.add(createSecurityObject("ApiKeyAuth", new ArrayList<>()));
			postOperation.put("security", security);
			swaggerSpec.put(part1, postOperation);
			result.append(objectMapper.writeValueAsString(swaggerSpec));

		}
		StringBuilder contents = null;
		contents = new StringBuilder();
		contents.append(result);

		Map<String, Object> pathmap = new HashMap<>();

		pathmap.put("paths", result);
		response = contents.toString();
		JsonNode jsonNode = objectMapper.readTree(contents.toString());
		return jsonNode;
	}

}
